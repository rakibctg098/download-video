import { pgTable, serial, text, varchar, bigint, timestamp } from "drizzle-orm/pg-core";

export const downloadHistory = pgTable("download_history", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title").notNull(),
  platform: varchar("platform", { length: 30 }).notNull(), // 'youtube', 'facebook', 'pinterest', 'direct', 'other'
  contentType: varchar("content_type", { length: 100 }),
  fileSizeBytes: bigint("file_size_bytes", { mode: "number" }),
  status: varchar("status", { length: 30 }).notNull(), // 'completed', 'validated', 'failed', 'fallback_link', 'social_opened'
  downloadMethod: varchar("download_method", { length: 50 }), // 'client_stream', 'server_stream', 'browser_link', 'external'
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type DownloadHistoryItem = typeof downloadHistory.$inferSelect;
export type NewDownloadHistoryItem = typeof downloadHistory.$inferInsert;
