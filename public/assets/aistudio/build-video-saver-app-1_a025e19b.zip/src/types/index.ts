export type ActiveTab = "saver" | "history" | "tests" | "settings" | "help";

export type DownloadEngine = "smart_stream" | "direct_link" | "server_proxy";

export interface AppSettings {
  downloadEngine: DownloadEngine;
  filenamePrefix: string;
  autoValidateOnPaste: boolean;
  maxSizeBytes: number; // e.g. 80 * 1024 * 1024
  language: "en" | "bn";
}

export interface VideoMetadata {
  url: string;
  platform: "youtube" | "facebook" | "pinterest" | "direct" | "unknown";
  category: "direct_media" | "social_media" | "invalid_scheme" | "invalid_format" | "general_webpage";
  isDirectMedia: boolean;
  contentType: string | null;
  contentLength: number | null;
  formattedSize: string | null;
  filename: string;
  title: string;
  thumbnailUrl: string | null;
  authorName?: string;
  isHtmlWebpage: boolean;
  supportsRanges: boolean;
  canDownloadInBrowser: boolean;
  message: string;
  messageBn: string;
  error?: string;
}

export interface DownloadProgressState {
  isDownloading: boolean;
  downloadedBytes: number;
  totalBytes: number | null;
  percentage: number | null; // null if total is unknown
  speedBytesPerSec: number;
  statusText: string;
  statusTextBn: string;
  error?: string;
}
