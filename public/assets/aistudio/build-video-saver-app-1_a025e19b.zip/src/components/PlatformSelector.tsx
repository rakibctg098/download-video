"use client";

import React from "react";
import { Film, Share2, Layers, Bookmark, PlaySquare } from "lucide-react";

export type PlatformFilter = "all" | "direct" | "youtube" | "facebook" | "pinterest";

interface PlatformSelectorProps {
  selected: PlatformFilter;
  onSelect: (platform: PlatformFilter) => void;
  language: "en" | "bn";
}

export const PlatformSelector: React.FC<PlatformSelectorProps> = ({
  selected,
  onSelect,
  language,
}) => {
  const platforms = [
    {
      id: "all" as PlatformFilter,
      label: language === "bn" ? "সকল লিংক" : "All Links",
      icon: Layers,
      activeBg: "bg-slate-800 border-indigo-500 text-white shadow-indigo-500/20",
      dot: "bg-slate-400",
    },
    {
      id: "direct" as PlatformFilter,
      label: "Direct MP4",
      icon: Film,
      activeBg: "bg-emerald-950/60 border-emerald-500 text-emerald-200 shadow-emerald-500/20",
      dot: "bg-emerald-400",
    },
    {
      id: "youtube" as PlatformFilter,
      label: "YouTube",
      icon: PlaySquare,
      activeBg: "bg-red-950/60 border-red-500 text-red-200 shadow-red-500/20",
      dot: "bg-red-400",
    },
    {
      id: "facebook" as PlatformFilter,
      label: "Facebook",
      icon: Share2,
      activeBg: "bg-blue-950/60 border-blue-500 text-blue-200 shadow-blue-500/20",
      dot: "bg-blue-400",
    },
    {
      id: "pinterest" as PlatformFilter,
      label: "Pinterest",
      icon: Bookmark,
      activeBg: "bg-rose-950/60 border-rose-500 text-rose-200 shadow-rose-500/20",
      dot: "bg-rose-400",
    },
  ];

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          {language === "bn" ? "প্ল্যাটফর্ম নির্বাচন করুন" : "Select Media Platform"}
        </span>
        <span className="text-[11px] text-slate-500">
          {language === "bn" ? "স্বতন্ত্র টুল (কোনো প্রাতিষ্ঠানিক সংযুক্তি নেই)" : "Independent Tool"}
        </span>
      </div>

      {/* Horizontal scrolling pill selector for mobile */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none -mx-1 px-1">
        {platforms.map((p) => {
          const isSelected = selected === p.id;
          const Icon = p.icon;
          return (
            <button
              key={p.id}
              onClick={() => onSelect(p.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border whitespace-nowrap transition-all duration-200 active:scale-95 flex-shrink-0 ${
                isSelected
                  ? `${p.activeBg} ring-1 shadow-md font-semibold`
                  : "bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{p.label}</span>
              {isSelected && <span className={`w-1.5 h-1.5 rounded-full ${p.dot} ml-0.5`} />}
            </button>
          );
        })}
      </div>
    </div>
  );
};
