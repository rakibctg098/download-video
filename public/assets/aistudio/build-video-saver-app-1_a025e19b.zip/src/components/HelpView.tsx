"use client";

import React, { useState } from "react";
import {
  HelpCircle,
  Smartphone,
  FolderDown,
  Globe,
  Film,
  AlertTriangle,
  CheckCircle2,
  Share2,
  Layers,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface HelpViewProps {
  language: "en" | "bn";
}

export const HelpView: React.FC<HelpViewProps> = ({ language }) => {
  const [openSection, setOpenSection] = useState<number | null>(1);

  const toggle = (num: number) => {
    setOpenSection(openSection === num ? null : num);
  };

  const sectionsBn = [
    {
      id: 1,
      title: "১. গুগল এআই স্টুডিওতে প্রিভিউ ও চালুর নিয়ম",
      icon: Globe,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            গুগল এআই স্টুডিও বা ক্লাউড এডিটরে আপনি যখন প্রম্পট দেন, তখন সিস্টেম স্বয়ংক্রিয়ভাবে একটি ফুলস্ট্যাক নেক্সটজেএস (Next.js) ও পোস্টগ্রেসকিউএল (PostgreSQL) অ্যাপ্লিকেশন তৈরি করে।
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-1 text-slate-300">
            <li>
              বিল্ড সম্পন্ন হলে ডানদিকের <strong>Preview</strong> উইন্ডো বা <strong>Open Preview URL</strong> অপশনে চাপ দিন।
            </li>
            <li>
              প্রিভিউটি একটি স্বয়ংক্রিয় ক্লাউড পোর্টে (যেমন <code>https://3000-....app</code>) লাইভ চালু হয়ে যায়।
            </li>
            <li>
              কোনো সার্ভার কমান্ড ম্যানুয়ালি রান করার প্রয়োজন নেই, প্ল্যাটফর্ম নিজেই ব্যাকগ্রাউন্ডে হেলথচেক নিশ্চিত করে অ্যাপটি চালু রাখে।
            </li>
          </ul>
        </div>
      ),
    },
    {
      id: 2,
      title: "২. অ্যান্ড্রয়েড ক্রোম ব্রাউজারে টেস্ট করার সহজ পদ্ধতি",
      icon: Smartphone,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            আপনার অ্যান্ড্রয়েড ১২ বা অ্যান্ড্রয়েড ১৩ চালিত ৪ জিবি র‍্যামের ফোনে টেস্ট করার জন্য:
          </p>
          <ol className="list-decimal list-inside space-y-1.5 pl-1 text-slate-300">
            <li>আপনার ফোনের <strong>Google Chrome</strong> ব্রাউজারটি ওপেন করুন।</li>
            <li>ওয়েব অ্যাপের প্রিভিউ লিংকটি কপি করে ক্রোমের অ্যাড্রেস বারে পেস্ট করে <strong>Enter</strong> চাপুন।</li>
            <li>
              অ্যাপটি মোবাইল-ফার্স্ট ডিজাইনে তৈরি, তাই ছোট স্ক্রিনেও বড় বড় টাচ বাটন দেখতে পাবেন।
            </li>
            <li>
              ব্রাউজারের ৩-ডট মেনু থেকে <strong>&quot;Add to Home screen&quot;</strong> চেপে এটিকে অ্যাপের মতো ফোনে আইকন হিসেবেও রেখে দিতে পারেন।
            </li>
          </ol>
        </div>
      ),
    },
    {
      id: 3,
      title: "৩. পাবলিক ইউআরএল বা ডিপ্লয়মেন্ট (অন্যকে লিংক পাঠানো)",
      icon: Share2,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            আপনি যদি বন্ধু বা অন্য ফোনে এই অ্যাপটি টেস্ট করাতে চান:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-1 text-slate-300">
            <li>
              <strong>পাবলিক প্রিভিউ URL:</strong> স্যান্ডবক্সের জেনারেট করা প্রিভিউ URL যেকোনো ব্রাউজারে কাজ করে।
            </li>
            <li>
              <strong>Vercel বা Render এ ডিপ্লয়:</strong> গিটহাবে কোডটি পুশ করে এক ক্লিকে Vercel-এ ডিপ্লয় করতে পারবেন। ডাটাবেজের জন্য Neon বা Supabase-এর ফ্রি পোস্টগ্রেস ইউআরএল দিলেই স্থায়ীভাবে চলবে।
            </li>
          </ul>
        </div>
      ),
    },
    {
      id: 4,
      title: "৪. টেস্ট এমপি৪ (MP4) ফাইল ডাউনলোড করার বাস্তব ধাপ",
      icon: Film,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            পরীক্ষা করার জন্য নিচের ধাপগুলো অনুসরণ করুন:
          </p>
          <ol className="list-decimal list-inside space-y-1.5 pl-1 text-slate-300">
            <li>হোম স্ক্রিনে থাকা <strong>&quot;Direct MP4 (Flower Sample)&quot;</strong> বাটনে চাপ দিন।</li>
            <li>ইনপুট বক্সে স্বয়ংক্রিয়ভাবে আসল MP4 ফাইল লিংকটি বসে যাবে।</li>
            <li>
              <strong>&quot;Validate Link&quot;</strong> বাটনে চাপুন। অ্যাপটি সার্ভারে পরীক্ষা করে নিশ্চিত করবে ফাইলটি আসলেই ভিডিও কি না এবং কত মেগাবাইট সাইজ।
            </li>
            <li>
              সবুজ সংকেত আসলে <strong>&quot;ভিডিও ডাউনলোড করুন&quot;</strong> বাটনে চাপ দিন।
            </li>
            <li>
              রিয়েল-টাইম প্রগ্রেস বারে মেগাবাইট এবং গতি দেখতে পাবেন। শেষ হলে ক্রোম আপনার স্টোরেজে ফাইল সেভ করার নোটিফিকেশন দেবে।
            </li>
          </ol>
        </div>
      ),
    },
    {
      id: 5,
      title: "৫. অ্যান্ড্রয়েডের Downloads ফোল্ডারে ফাইলটি খোঁজার উপায়",
      icon: FolderDown,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            ডাউনলোড হওয়া ভিডিও ফাইলটি কোথায় জমা হয়েছে জানতে:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-1 text-slate-300">
            <li>
              <strong>পদ্ধতি ক (ক্রোম থেকে):</strong> ক্রোম ব্রাউজারের উপরে ডানদিকের ৩-ডটে চাপ দিন এবং <strong>&quot;Downloads&quot;</strong> নির্বাচন করুন। সেখানে ফাইলটি দেখতে পাবেন এবং ট্যাপ করলেই প্লে হবে।
            </li>
            <li>
              <strong>পদ্ধতি খ (ফাইল ম্যানেজার থেকে):</strong> ফোনে থাকা <strong>Files by Google</strong> বা <strong>My Files</strong> অ্যাপে যান। <strong>&quot;Downloads&quot;</strong> ফোল্ডারে গেলে <code>BigBuckBunny.mp4</code> বা <code>VideoSaver_...mp4</code> দেখতে পাবেন।
            </li>
          </ul>
        </div>
      ),
    },
    {
      id: 6,
      title: "৬. Movies/VideoSaver ফোল্ডারে সরানো ও গ্যালারিতে দেখার নিয়ম",
      icon: Layers,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            ভিডিওটি নিজের পছন্দের ফোল্ডারে সাজিয়ে রাখতে:
          </p>
          <ol className="list-decimal list-inside space-y-1.5 pl-1 text-slate-300">
            <li><strong>Files by Google</strong> ওপেন করে <strong>Downloads</strong> এ যান।</li>
            <li>ফাইলের পাশের ৩-ডটে ট্যাপ করে <strong>&quot;Move to&quot;</strong> চাপুন।</li>
            <li><strong>Internal Storage &gt; Movies</strong> ফোল্ডারে যান।</li>
            <li>উপরে <strong>&quot;Add folder&quot;</strong> চেপে <code>VideoSaver</code> ফোল্ডার বানান এবং <strong>&quot;Move here&quot;</strong> চাপুন।</li>
            <li>
              <strong>গ্যালারিতে দেখা:</strong> অ্যান্ড্রয়েডের ব্যাকগ্রাউন্ড স্ক্যানার স্বয়ংক্রিয়ভাবে ভিডিওটি স্ক্যান করে। আপনার গ্যালারি বা গুগল ফটোজে ২-৫ সেকেন্ডের মধ্যে ভিডিওটি অ্যালবামে দৃশ্যমান হবে।
            </li>
          </ol>
        </div>
      ),
    },
    {
      id: 7,
      title: "৭. ওয়েব অ্যাপ্লিকেশন বনাম নেটিভ APK-এর মধ্যে পার্থক্য ও সীমাবদ্ধতা",
      icon: AlertTriangle,
      content: (
        <div className="space-y-2.5 text-slate-300">
          <p className="font-medium text-amber-300">
            সততা ও স্বচ্ছতার জন্য জানা জরুরি ওয়েব অ্যাপ কী পারে এবং কী পারে না:
          </p>
          <div className="space-y-2 text-xs">
            <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
              <strong className="text-emerald-400">১. ব্রাউজার স্যান্ডবক্স নিরাপত্তা:</strong>
              <p className="mt-0.5 text-slate-400">
                ওয়েব অ্যাপ সরাসরি আপনার ফোনের ইন্টারনাল প্রাইভেট সিস্টেমে গোপনে ফাইল ঢুকিয়ে দিতে পারে না। এটি ব্রাউজারের নিরাপদ Downloads ডিরেক্টরি ব্যবহার করে, যা আপনার ৪ জিবি র‍্যামের ফোনকে ভাইরাসমুক্ত ও দ্রুত রাখে।
              </p>
            </div>
            <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
              <strong className="text-amber-400">২. ফেসবুক ও ইউটিউব নীতি:</strong>
              <p className="mt-0.5 text-slate-400">
                ইউটিউব ও ফেসবুকের ভিডিও ব্রাউজারের ভেতর থেকে কোনো পাইরেটেড পদ্ধতিতে রিপ বা ডিকোড করা যায় না। এ কারণেই আমাদের অ্যাপ কোনো ভুয়া ডামি প্রগ্রেস বা ফেক ফাইল দেখায় না; বরং আপনাকে আসল ভিডিও লিংক ও প্রিভিউ দেখার নিরাপদ উপায় প্রদান করে।
              </p>
            </div>
            <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
              <strong className="text-indigo-400">৩. মেমোরি নিয়ন্ত্রণ (৪ জিবি র‍্যাম):</strong>
              <p className="mt-0.5 text-slate-400">
                বড় ফাইল মেমোরিতে পুরো জমা না করে সরাসরি ব্রাউজার স্ট্রিমে পাঠানো হয়, যাতে লো-র‍্যাম অ্যান্ড্রয়েড ক্র্যাশ না করে।
              </p>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const sectionsEn = [
    {
      id: 1,
      title: "1. Google AI Studio Setup & Preview",
      icon: Globe,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            The platform automatically compiles and starts the Next.js server with PostgreSQL.
          </p>
          <ul className="list-disc list-inside space-y-1 pl-1">
            <li>Click the preview window or open the preview URL in your browser.</li>
            <li>No manual command-line execution is needed; the sandbox orchestrates health checks.</li>
          </ul>
        </div>
      ),
    },
    {
      id: 2,
      title: "2. Testing on Android Chrome",
      icon: Smartphone,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            On your Android 12 or 13 phone with 4 GB RAM:
          </p>
          <ol className="list-decimal list-inside space-y-1 pl-1">
            <li>Open Google Chrome.</li>
            <li>Paste the preview web URL into Chrome&apos;s address bar.</li>
            <li>The UI is mobile-optimized with 48px touch targets for easy one-handed thumb use.</li>
            <li>You can tap Chrome&apos;s menu (⋮) &gt; &quot;Add to Home screen&quot; to install it like an app.</li>
          </ol>
        </div>
      ),
    },
    {
      id: 3,
      title: "3. Publishing & Public Deployment",
      icon: Share2,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            To share with others or run 24/7:
          </p>
          <ul className="list-disc list-inside space-y-1 pl-1">
            <li>Use the sandbox preview URL for immediate testing on physical devices.</li>
            <li>For production, deploy to Vercel or Render with a Neon PostgreSQL database.</li>
          </ul>
        </div>
      ),
    },
    {
      id: 4,
      title: "4. Downloading a Test MP4 Video",
      icon: Film,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            Step-by-step verification using direct MP4 files:
          </p>
          <ol className="list-decimal list-inside space-y-1 pl-1">
            <li>Tap the &quot;Direct MP4 (Flower Sample)&quot; quick-pill on the home screen.</li>
            <li>Click &quot;Validate Link&quot;. The server inspects headers and confirms Content-Type and size.</li>
            <li>Click &quot;Download Video&quot; to start the genuine streaming download.</li>
            <li>Observe real byte progress, speed (MB/s), and Chrome&apos;s system notification.</li>
          </ol>
        </div>
      ),
    },
    {
      id: 5,
      title: "5. Locating Files in Android Downloads",
      icon: FolderDown,
      content: (
        <div className="space-y-2 text-slate-300">
          <ul className="list-disc list-inside space-y-1 pl-1">
            <li><strong>Via Chrome:</strong> Tap Chrome&apos;s menu (⋮) &gt; Downloads to play immediately.</li>
            <li><strong>Via Files app:</strong> Open &quot;Files by Google&quot; or Samsung &quot;My Files&quot; &gt; Downloads.</li>
          </ul>
        </div>
      ),
    },
    {
      id: 6,
      title: "6. Moving to Movies/VideoSaver & Gallery Visibility",
      icon: Layers,
      content: (
        <div className="space-y-2 text-slate-300">
          <ol className="list-decimal list-inside space-y-1 pl-1">
            <li>In Files by Google, find the downloaded MP4 in Downloads.</li>
            <li>Tap the three dots (⋮) &gt; &quot;Move to&quot; &gt; Internal storage &gt; &quot;Movies&quot;.</li>
            <li>Create a folder named &quot;VideoSaver&quot; and tap &quot;Move here&quot;.</li>
            <li>Android&apos;s MediaScanner automatically scans the folder and adds it to your Gallery.</li>
          </ol>
        </div>
      ),
    },
    {
      id: 7,
      title: "7. Web App vs Native Android APK Limitations",
      icon: AlertTriangle,
      content: (
        <div className="space-y-2 text-slate-300">
          <p>
            Web applications adhere to browser security sandboxes:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-1">
            <li>Cannot covertly write to arbitrary system folders without standard browser downloads.</li>
            <li>Does not run battery-draining background daemons.</li>
            <li>Respects copyright and platform policies (no unauthorized YouTube/Facebook DRM scraping).</li>
            <li>Keeps your 4 GB RAM device responsive and free from bloatware.</li>
          </ul>
        </div>
      ),
    },
  ];

  const sections = language === "bn" ? sectionsBn : sectionsEn;

  return (
    <div className="space-y-4">
      {/* Title */}
      <div>
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-indigo-400" />
          <span>
            {language === "bn"
              ? "ব্যবহার ও টেস্টিং নির্দেশিকা (সহজ বাংলা)"
              : "User & Testing Guide (Beginner Friendly)"}
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          {language === "bn"
            ? "অ্যান্ড্রয়েড ১২/১৩ ও ৪ জিবি র‍্যাম ফোনের জন্য বিস্তারিত গাইড"
            : "Complete instructions for Android 12/13 and 4 GB RAM smartphones"}
        </p>
      </div>

      {/* Accordion List */}
      <div className="space-y-2.5">
        {sections.map((sec) => {
          const isOpen = openSection === sec.id;
          const Icon = sec.icon;
          return (
            <div
              key={sec.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md transition-all"
            >
              <button
                type="button"
                onClick={() => toggle(sec.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-800/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg bg-indigo-950/80 border border-indigo-800/50 flex items-center justify-center text-indigo-400 flex-shrink-0">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <h3 className="text-xs sm:text-sm font-semibold text-white">{sec.title}</h3>
                </div>

                <div className="text-slate-400 p-1">
                  {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 text-xs border-t border-slate-800/80 leading-relaxed">
                  {sec.content}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
