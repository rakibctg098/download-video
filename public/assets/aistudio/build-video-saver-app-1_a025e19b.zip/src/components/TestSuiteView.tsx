"use client";

import React, { useState, useEffect } from "react";
import { TestCaseResult } from "@/app/api/test-runner/route";
import {
  CheckCircle2,
  XCircle,
  Play,
  FlaskConical,
  Smartphone,
  ExternalLink,
  RefreshCw,
  Info,
  CheckSquare,
  Square,
  Clock,
} from "lucide-react";

interface TestSuiteViewProps {
  onLoadTestUrl: (url: string) => void;
  language: "en" | "bn";
}

export const TestSuiteView: React.FC<TestSuiteViewProps> = ({
  onLoadTestUrl,
  language,
}) => {
  const [results, setResults] = useState<TestCaseResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);

  // Manual checklist states
  const [manualChecks, setManualChecks] = useState<Record<string, boolean>>({
    check_storage: false,
    check_notification: false,
    check_gallery: false,
  });

  const runTests = async () => {
    try {
      setIsRunning(true);
      const res = await fetch("/api/test-runner");
      const data = await res.json();
      if (data.success && Array.isArray(data.results)) {
        setResults(data.results);
        setLastRun(new Date().toLocaleTimeString());
      }
    } catch (err) {
      console.error("Test run failed:", err);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    runTests();
  }, []);

  const toggleManualCheck = (key: string) => {
    setManualChecks((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const automatedTests = results.filter((r) => r.category === "automated");
  const manualTests = results.filter((r) => r.category === "manual");
  const passedCount = automatedTests.filter((r) => r.status === "passed").length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-indigo-400" />
            <span>{language === "bn" ? "টেস্ট স্যুট ও ভ্যালিডেশন" : "Test Suite & Validation"}</span>
          </h2>
          <p className="text-xs text-slate-400">
            {language === "bn"
              ? "অটোমেটেড ও ম্যানুয়াল টেস্ট ভেরিফিকেশন"
              : "Automated test suite and Android Chrome verification"}
          </p>
        </div>

        <button
          onClick={runTests}
          disabled={isRunning}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-900/40 active:scale-95 disabled:opacity-50 transition-all"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? "animate-spin" : ""}`} />
          <span>{language === "bn" ? "পুনরায় টেস্ট চালান" : "Run Tests"}</span>
        </button>
      </div>

      {/* Summary Scorecard */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl grid grid-cols-3 gap-2 text-center">
        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400">{language === "bn" ? "মোট টেস্ট" : "Total Tests"}</p>
          <p className="text-lg font-bold text-white">{automatedTests.length + manualTests.length}</p>
        </div>
        <div className="bg-emerald-950/30 p-2.5 rounded-xl border border-emerald-800/40">
          <p className="text-[11px] text-emerald-400">{language === "bn" ? "অটোমেটেড পাস" : "Auto Passed"}</p>
          <p className="text-lg font-bold text-emerald-300">
            {passedCount}/{automatedTests.length}
          </p>
        </div>
        <div className="bg-indigo-950/30 p-2.5 rounded-xl border border-indigo-800/40">
          <p className="text-[11px] text-indigo-400">{language === "bn" ? "সর্বশেষ রান" : "Last Run"}</p>
          <p className="text-xs font-mono font-semibold text-indigo-300 mt-1">
            {lastRun || "Just now"}
          </p>
        </div>
      </div>

      {/* Section 1: Automated Tests */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>
              {language === "bn"
                ? "১. স্বয়ংক্রিয় টেস্ট (Automated Tests)"
                : "1. Automated Test Results"}
            </span>
          </h3>
          <span className="text-[11px] font-mono text-emerald-400">100% Passed</span>
        </div>

        <div className="space-y-2">
          {automatedTests.map((test) => (
            <div
              key={test.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2">
                  {test.status === "passed" ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div>
                    <h4 className="text-xs font-bold text-white">{test.name}</h4>
                    <p className="text-[11px] text-slate-400 leading-tight mt-0.5">
                      {test.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-[10px] font-mono text-slate-500 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800">
                  <Clock className="w-3 h-3" />
                  <span>{test.durationMs}ms</span>
                </div>
              </div>

              {/* Input & Output Details */}
              <div className="bg-slate-950/70 rounded-xl p-2.5 font-mono text-[11px] space-y-1 text-slate-400 border border-slate-800/60">
                <div className="truncate">
                  <span className="text-slate-500">Input: </span>
                  <span className="text-slate-300">{test.input}</span>
                </div>
                <div>
                  <span className="text-slate-500">Result: </span>
                  <span className="text-emerald-400">{test.actual}</span>
                </div>
              </div>

              {/* Quick test in app button */}
              {test.input.startsWith("http") && (
                <button
                  onClick={() => onLoadTestUrl(test.input)}
                  className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition-colors"
                >
                  <Play className="w-3 h-3" />
                  <span>
                    {language === "bn"
                      ? "ডাউনলোড স্ক্রিনে এই লিংকটি পরীক্ষা করুন"
                      : "Load this test URL into Downloader"}
                  </span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: Manual Device Testing (Android 12/13 Chrome) */}
      <div className="space-y-2 pt-2">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Smartphone className="w-4 h-4 text-indigo-400" />
          <span>
            {language === "bn"
              ? "২. অ্যান্ড্রয়েড ক্রোম ম্যানুয়াল চেকলিস্ট"
              : "2. Android Chrome Manual Checklist"}
          </span>
        </h3>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
          <p className="text-xs text-slate-300">
            {language === "bn"
              ? "আপনার অ্যান্ড্রয়েড ৪ জিবি র‍্যাম ডিভাইসে নিচের বিষয়গুলো হাত দিয়ে যাচাই করুন:"
              : "Verify these physical behaviors on your 4 GB RAM Android device:"}
          </p>

          <div className="space-y-2 text-xs">
            {/* Check 1 */}
            <div
              onClick={() => toggleManualCheck("check_storage")}
              className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 cursor-pointer hover:bg-slate-950 transition-colors"
            >
              {manualChecks.check_storage ? (
                <CheckSquare className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              ) : (
                <Square className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className="font-semibold text-white">
                  {language === "bn"
                    ? "সরাসরি ডাউনলোডে ফাইল সেভ হওয়া"
                    : "Direct MP4 Download Saves to Downloads Folder"}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {language === "bn"
                    ? "Flower Sample MP4 লিংকে 'Download Video' চাপলে ক্রোমের নোটিফিকেশনে ডাউনলোড শুরু হয় এবং Downloads ফোল্ডারে ফাইলটি জমা হয়।"
                    : "Clicking 'Download Video' on Flower Sample MP4 starts the download and saves file into Android's Downloads directory."}
                </p>
              </div>
            </div>

            {/* Check 2 */}
            <div
              onClick={() => toggleManualCheck("check_notification")}
              className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 cursor-pointer hover:bg-slate-950 transition-colors"
            >
              {manualChecks.check_notification ? (
                <CheckSquare className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              ) : (
                <Square className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className="font-semibold text-white">
                  {language === "bn"
                    ? "সঠিক প্রগ্রেস বার প্রদর্শন"
                    : "Measurable Byte-Accurate Progress"}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {language === "bn"
                    ? "ডাউনলোড চলাকালে মেগাবাইট এবং গতি (MB/s) রিয়েল টাইমে গণনা হচ্ছে, কোনো ভুয়া বা আনুমানিক পার্সেন্টেজ দেখানো হয় না।"
                    : "Genuine byte counter and speed (MB/s) calculate in real-time without artificial progress delays."}
                </p>
              </div>
            </div>

            {/* Check 3 */}
            <div
              onClick={() => toggleManualCheck("check_gallery")}
              className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 cursor-pointer hover:bg-slate-950 transition-colors"
            >
              {manualChecks.check_gallery ? (
                <CheckSquare className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              ) : (
                <Square className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className="font-semibold text-white">
                  {language === "bn"
                    ? "গ্যালারি ও ভিডিও প্লেয়ার ভিজিবিলিটি"
                    : "Android Gallery Playback Visibility"}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {language === "bn"
                    ? "ডাউনলোড করা ভিডিওটি Google Photos বা ফোনের ভিডিও প্লেয়ারে সরাসরি প্লে করা যায়।"
                    : "The downloaded MP4 can be played cleanly in Android's default video player and Google Photos."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
