"use client";

import React, { useState } from "react";
import { VideoMetadata } from "@/types";
import {
  ExternalLink,
  Download,
  AlertTriangle,
  CheckCircle2,
  Copy,
  Check,
  FileVideo,
  Info,
  ShieldAlert,
  Play,
} from "lucide-react";

interface VideoInfoCardProps {
  metadata: VideoMetadata;
  onDownload: () => void;
  isDownloading: boolean;
  language: "en" | "bn";
}

export const VideoInfoCard: React.FC<VideoInfoCardProps> = ({
  metadata,
  onDownload,
  isDownloading,
  language,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(metadata.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const isDirect = metadata.category === "direct_media" || metadata.isDirectMedia;
  const isSocial = metadata.category === "social_media";
  const isError = !metadata.canDownloadInBrowser && !isSocial;

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-4">
      {/* Header with Badges */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Platform Badge */}
          <span
            className={`text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider ${
              metadata.platform === "youtube"
                ? "bg-red-950/80 text-red-300 border border-red-800/60"
                : metadata.platform === "facebook"
                ? "bg-blue-950/80 text-blue-300 border border-blue-800/60"
                : metadata.platform === "pinterest"
                ? "bg-rose-950/80 text-rose-300 border border-rose-800/60"
                : metadata.platform === "direct"
                ? "bg-emerald-950/80 text-emerald-300 border border-emerald-800/60"
                : "bg-slate-800 text-slate-300 border border-slate-700"
            }`}
          >
            {metadata.platform}
          </span>

          {/* Type Classification Badge */}
          <span
            className={`text-xs px-2.5 py-1 rounded-full font-medium ${
              isDirect
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                : "bg-amber-500/10 text-amber-300 border border-amber-500/30"
            }`}
          >
            {isDirect
              ? language === "bn"
                ? "ডিরেক্ট মিডিয়া ফাইল"
                : "Direct Media File"
              : language === "bn"
              ? "সোশ্যাল ওয়েবপেজ"
              : "Social Media Page"}
          </span>

          {/* MIME type / Size */}
          {metadata.contentType && (
            <span className="text-[11px] font-mono bg-slate-800/80 text-slate-300 px-2 py-1 rounded-lg border border-slate-700">
              {metadata.contentType}
            </span>
          )}

          {metadata.formattedSize && (
            <span className="text-[11px] font-mono bg-indigo-950/60 text-indigo-300 px-2 py-1 rounded-lg border border-indigo-800/50">
              {metadata.formattedSize}
            </span>
          )}
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          title="Copy Link"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>

      {/* Thumbnail preview if YouTube oEmbed or thumbnail available */}
      {metadata.thumbnailUrl && (
        <div className="relative rounded-xl overflow-hidden aspect-video bg-black/40 border border-slate-800 group">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={metadata.thumbnailUrl}
            alt={metadata.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
            <div className="flex items-center gap-2 text-white text-xs">
              <Play className="w-4 h-4 text-red-500 fill-red-500" />
              <span className="font-medium truncate">{metadata.authorName || "Verified Preview"}</span>
            </div>
          </div>
        </div>
      )}

      {/* Video Title & Filename */}
      <div>
        <h3 className="text-base font-bold text-white line-clamp-2">{metadata.title}</h3>
        <p className="text-xs font-mono text-slate-400 mt-1 flex items-center gap-1.5">
          <FileVideo className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
          <span className="truncate">{metadata.filename}</span>
        </p>
      </div>

      {/* Honest Limitation / Explanation Box */}
      <div
        className={`rounded-xl p-3.5 border text-xs leading-relaxed ${
          isDirect
            ? "bg-emerald-950/30 border-emerald-800/50 text-emerald-200"
            : isSocial
            ? "bg-blue-950/30 border-blue-800/50 text-blue-200"
            : "bg-amber-950/30 border-amber-800/50 text-amber-200"
        }`}
      >
        <div className="flex items-start gap-2.5">
          {isDirect ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
          ) : isSocial ? (
            <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          )}

          <div>
            <p className="font-semibold mb-1">
              {isDirect
                ? language === "bn"
                  ? "ডাউনলোড উপযোগী ফাইল"
                  : "Ready for Browser Download"
                : isSocial
                ? language === "bn"
                  ? "অফিসিয়াল নীতি ও প্ল্যাটফর্ম তথ্য"
                  : "Official Platform Information"
                : language === "bn"
                ? "বিজ্ঞপ্তি ও সীমাবদ্ধতা"
                : "Notice & Limitations"}
            </p>
            <p className="opacity-90">
              {language === "bn" ? metadata.messageBn : metadata.message}
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
        {/* Direct Download Button (Active only when valid direct media) */}
        {metadata.canDownloadInBrowser && (
          <button
            onClick={onDownload}
            disabled={isDownloading}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white shadow-lg shadow-emerald-900/30 active:scale-[0.98] transition-all disabled:opacity-50 min-h-[48px]"
          >
            <Download className="w-4 h-4" />
            <span>
              {isDownloading
                ? language === "bn"
                  ? "ডাউনলোড হচ্ছে..."
                  : "Downloading..."
                : language === "bn"
                ? "ভিডিও ডাউনলোড করুন"
                : "Download Video"}
            </span>
          </button>
        )}

        {/* Fallback Direct Browser Download link (Useful if CORS blocks stream) */}
        {isDirect && (
          <a
            href={metadata.url}
            download={metadata.filename}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-[0.98] transition-all min-h-[48px]"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>
              {language === "bn"
                ? "ক্রোম সরাসরি ডাউনলোড (Fallback)"
                : "Chrome Native Download (Fallback)"}
            </span>
          </a>
        )}

        {/* Open Original Video Button (For social media or external review) */}
        <a
          href={metadata.url}
          target="_blank"
          rel="noopener noreferrer"
          className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-xs border active:scale-[0.98] transition-all min-h-[48px] ${
            isSocial
              ? "flex-1 bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500 shadow-md shadow-indigo-900/30 text-sm font-semibold"
              : "bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700"
          }`}
        >
          <ExternalLink className="w-4 h-4" />
          <span>
            {language === "bn" ? "আসল ভিডিও দেখুন" : "Open Original Video"}
          </span>
        </a>
      </div>
    </div>
  );
};
