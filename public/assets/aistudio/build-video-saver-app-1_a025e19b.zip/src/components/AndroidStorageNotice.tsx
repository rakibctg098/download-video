"use client";

import React, { useState } from "react";
import { FolderDown, Smartphone, ChevronDown, ChevronUp, Image, Shield } from "lucide-react";

interface AndroidStorageNoticeProps {
  language: "en" | "bn";
}

export const AndroidStorageNotice: React.FC<AndroidStorageNoticeProps> = ({ language }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300 space-y-3">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-semibold text-white text-sm">
              {language === "bn"
                ? "অ্যান্ড্রয়েড ফাইল সেভিং ও স্টোরেজ নির্দেশিকা"
                : "Android File Saving & Storage Guide"}
            </h4>
            <p className="text-[11px] text-slate-400">
              {language === "bn"
                ? "অ্যান্ড্রয়েড ১২/১৩ ও ক্রোম ব্রাউজারের কাজের নিয়ম"
                : "How Android 12/13 & Chrome store your videos"}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Toggle details"
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Brief Summary always visible */}
      <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 space-y-1.5">
        <div className="flex items-center gap-2 text-emerald-400 font-medium">
          <FolderDown className="w-4 h-4 flex-shrink-0" />
          <span>
            {language === "bn"
              ? "ডিফল্ট লোকেশন: Internal Storage > Downloads"
              : "Default Location: Internal Storage > Downloads"}
          </span>
        </div>
        <p className="text-slate-400 text-[11px] leading-relaxed">
          {language === "bn"
            ? "ওয়েব ব্রাউজার নিরাপত্তাজনিত কারণে যেকোনো ফোল্ডারে ফাইল লিখতে পারে না। ক্রোম স্বয়ংক্রিয়ভাবে ডাউনলোডকৃত ফাইল 'Downloads' ফোল্ডারে জমা রাখে।"
            : "For security, web browsers cannot silently write to arbitrary system folders. Android Chrome automatically saves downloads to your device's Downloads directory."}
        </p>
      </div>

      {/* Expanded detailed instructions */}
      {isExpanded && (
        <div className="space-y-3 pt-1 border-t border-slate-800 text-[11px] leading-relaxed text-slate-300">
          <div>
            <h5 className="font-semibold text-white flex items-center gap-1.5 mb-1">
              <FolderDown className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                {language === "bn"
                  ? "Movies/VideoSaver ফোল্ডারে ফাইল সরানোর নিয়ম:"
                  : "How to move files to Movies/VideoSaver:"}
              </span>
            </h5>
            <ol className="list-decimal list-inside space-y-1 pl-1 text-slate-300">
              <li>
                {language === "bn"
                  ? "আপনার ফোনের 'Files by Google' (অথবা Samsung 'My Files') অ্যাপ ওপেন করুন।"
                  : "Open 'Files by Google' (or Samsung 'My Files') on your Android phone."}
              </li>
              <li>
                {language === "bn"
                  ? "'Downloads' ক্যাটাগরিতে গিয়ে সদ্য ডাউনলোড করা MP4 ফাইলটি খুঁজে বের করুন।"
                  : "Go to the 'Downloads' folder and locate the downloaded MP4 video."}
              </li>
              <li>
                {language === "bn"
                  ? "ফাইলের পাশের ৩-ডট (⋮) চেপে 'Move to' বা 'Internal storage > Movies' নির্বাচন করুন।"
                  : "Tap the 3 dots (⋮) next to the file, tap 'Move to' > Internal storage > 'Movies'."}
              </li>
              <li>
                {language === "bn"
                  ? "সেখানে 'Add new folder' চেপে 'VideoSaver' নাম দিন এবং 'Move here' করুন।"
                  : "Tap 'Create folder', name it 'VideoSaver', and tap 'Move here'."}
              </li>
            </ol>
          </div>

          <div>
            <h5 className="font-semibold text-white flex items-center gap-1.5 mb-1">
              <Image className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {language === "bn"
                  ? "গ্যালারিতে (Gallery) দৃশ্যমান হওয়া:"
                  : "Android Gallery Visibility:"}
              </span>
            </h5>
            <p className="text-slate-400">
              {language === "bn"
                ? "অ্যান্ড্রয়েডের MediaScanner সার্ভিস স্বয়ংক্রিয়ভাবে নতুন MP4 ফাইল স্ক্যান করে গ্যালারি বা গুগল ফটোজে যুক্ত করে। যদি সাথে সাথে না দেখায়, গ্যালারি অ্যাপটি একবার বন্ধ করে পুনরায় ওপেন করুন।"
                : "Android's background MediaScanner automatically indexes newly downloaded MP4 videos into Google Photos and your device Gallery within a few seconds."}
            </p>
          </div>

          <div className="bg-indigo-950/30 border border-indigo-800/40 rounded-xl p-2.5 flex items-start gap-2">
            <Shield className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
            <p className="text-indigo-200">
              {language === "bn"
                ? "ব্রাউজার নিরাপত্তা স্যান্ডবক্স: ওয়েব অ্যাপ কোনো ক্ষতিকর ব্যাকগ্রাউন্ড এক্টিভিটি চালাতে পারে না এবং আপনার ৪ জিবি র‍্যামের ফোনে মেমোরি নিরাপদ রাখে।"
                : "Chrome Sandbox: This web app runs strictly in your browser sandbox, keeping your 4 GB RAM phone fast, private, and malware-free."}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
