"use client";

import React, { useState, useEffect } from "react";
import { DownloadHistoryItem } from "@/db/schema";
import {
  Trash2,
  ExternalLink,
  Copy,
  Check,
  RotateCcw,
  Clock,
  HardDrive,
  Info,
  CheckCircle2,
  AlertCircle,
  FileVideo,
} from "lucide-react";

interface HistoryViewProps {
  onSelectUrlForDownload: (url: string) => void;
  language: "en" | "bn";
}

function formatBytes(bytes: number | null): string {
  if (!bytes || bytes === 0) return "Unknown size";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function formatDate(dateStr: Date | string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return String(dateStr);
  }
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  onSelectUrlForDownload,
  language,
}) => {
  const [history, setHistory] = useState<DownloadHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [isClearing, setIsClearing] = useState(false);

  const fetchHistory = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.success && Array.isArray(data.items)) {
        setHistory(data.items);
      }
    } catch (err) {
      console.error("Failed to fetch history:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleCopy = async (id: number, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleDeleteItem = async (id: number) => {
    try {
      const res = await fetch(`/api/history?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setHistory((prev) => prev.filter((item) => item.id !== id));
      }
    } catch (err) {
      console.error("Failed to delete history item:", err);
    }
  };

  const handleClearAll = async () => {
    const confirmMsg =
      language === "bn"
        ? "আপনি কি নিশ্চিতভাবে সব হিস্টোরি মুছে ফেলতে চান?"
        : "Are you sure you want to clear all download history?";
    if (!window.confirm(confirmMsg)) return;

    try {
      setIsClearing(true);
      const res = await fetch("/api/history", { method: "DELETE" });
      if (res.ok) {
        setHistory([]);
      }
    } catch (err) {
      console.error("Failed to clear history:", err);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <span>{language === "bn" ? "ডাউনলোড ও লিংক হিস্টোরি" : "Download & Link History"}</span>
          </h2>
          <p className="text-xs text-slate-400">
            {language === "bn"
              ? "আপনার পূর্ববর্তী সকল প্রসেস করা ভিডিও লিংক"
              : "Previously validated and downloaded videos"}
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={handleClearAll}
            disabled={isClearing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-red-300 bg-red-950/50 hover:bg-red-900/50 border border-red-800/50 transition-all active:scale-95 disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{language === "bn" ? "সব মুছুন" : "Clear All"}</span>
          </button>
        )}
      </div>

      {/* Storage Limitation Disclaimer Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 text-xs text-slate-300 space-y-2">
        <div className="flex items-start gap-2">
          <Info className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-white">
              {language === "bn"
                ? "ব্রাউজার স্টোরেজ ও ফাইল অ্যাক্সেসের সীমাবদ্ধতা"
                : "Browser Storage & Local File Limitations"}
            </p>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {language === "bn"
                ? "ব্রাউজারের সুরক্ষানীতি অনুযায়ী ডাউনলোড হয়ে যাওয়ার পর স্বয়ংক্রিয়ভাবে আপনার ইন্টারনাল স্টোরেজের আসল ফাইলটি সরাসরি ব্রাউজারে রি-ওপেন করা সম্ভব নয়। ফাইলটি দেখতে আপনার ফোনের 'Files by Google' বা 'Downloads' ফোল্ডারে যান।"
                : "Due to browser sandbox security policies, web apps cannot maintain persistent pointers to files stored in your Android device's Downloads directory. To watch downloaded files, open Files by Google or your Gallery."}
            </p>
          </div>
        </div>
      </div>

      {/* History Items List */}
      {isLoading ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
          {language === "bn" ? "হিস্টোরি লোড হচ্ছে..." : "Loading history records..."}
        </div>
      ) : history.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center space-y-2">
          <HardDrive className="w-8 h-8 text-slate-600 mx-auto" />
          <h4 className="text-sm font-semibold text-slate-300">
            {language === "bn" ? "কোনো হিস্টোরি পাওয়া যায়নি" : "No Download History Yet"}
          </h4>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            {language === "bn"
              ? "কোনো লিংক ভ্যালিডেট বা ডাউনলোড করলে তা এখানে তালিকাভুক্ত হবে।"
              : "When you validate or download videos, your session records will appear here."}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {history.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 shadow-md hover:border-slate-700 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Platform Tag */}
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                        item.platform === "youtube"
                          ? "bg-red-950/80 text-red-300 border border-red-800/60"
                          : item.platform === "facebook"
                          ? "bg-blue-950/80 text-blue-300 border border-blue-800/60"
                          : item.platform === "pinterest"
                          ? "bg-rose-950/80 text-rose-300 border border-rose-800/60"
                          : item.platform === "direct"
                          ? "bg-emerald-950/80 text-emerald-300 border border-emerald-800/60"
                          : "bg-slate-800 text-slate-300 border border-slate-700"
                      }`}
                    >
                      {item.platform}
                    </span>

                    {/* Status Badge */}
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-medium flex items-center gap-1 ${
                        item.status === "completed"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : item.status === "fallback_link"
                          ? "bg-blue-500/10 text-blue-400 border border-blue-500/30"
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                      }`}
                    >
                      {item.status === "completed" ? (
                        <CheckCircle2 className="w-2.5 h-2.5" />
                      ) : (
                        <AlertCircle className="w-2.5 h-2.5" />
                      )}
                      <span>{item.status}</span>
                    </span>

                    {/* Size */}
                    {item.fileSizeBytes && (
                      <span className="text-[10px] font-mono text-slate-400">
                        {formatBytes(item.fileSizeBytes)}
                      </span>
                    )}
                  </div>

                  {/* Title */}
                  <h4 className="text-xs font-semibold text-white line-clamp-1">
                    {item.title}
                  </h4>
                </div>

                {/* Date */}
                <span className="text-[10px] font-mono text-slate-500 flex-shrink-0">
                  {formatDate(item.createdAt)}
                </span>
              </div>

              {/* URL */}
              <p className="text-[11px] font-mono text-slate-400 truncate bg-slate-950/60 px-2.5 py-1.5 rounded-lg border border-slate-800/60">
                {item.url}
              </p>

              {/* Action Buttons Row */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-800/60">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectUrlForDownload(item.url)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-emerald-300 bg-emerald-950/50 hover:bg-emerald-900/50 border border-emerald-800/50 transition-all active:scale-95"
                    title="Reload in Downloader"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>{language === "bn" ? "পুনরায় নির্বাচন" : "Reload"}</span>
                  </button>

                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-all"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>{language === "bn" ? "ওপেন" : "Open"}</span>
                  </a>

                  <button
                    onClick={() => handleCopy(item.id, item.url)}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
                    title="Copy URL"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                </div>

                <button
                  onClick={() => handleDeleteItem(item.id)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-950/40 transition-all"
                  title="Delete Item"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
