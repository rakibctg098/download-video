"use client";

import React, { useState } from "react";
import { Clipboard, X, Search, Sparkles, CheckCircle2 } from "lucide-react";
import { PlatformFilter } from "./PlatformSelector";

interface UrlInputSectionProps {
  url: string;
  onUrlChange: (newUrl: string) => void;
  onValidate: () => void;
  isValidating: boolean;
  selectedPlatform: PlatformFilter;
  language: "en" | "bn";
}

export const UrlInputSection: React.FC<UrlInputSectionProps> = ({
  url,
  onUrlChange,
  onValidate,
  isValidating,
  selectedPlatform,
  language,
}) => {
  const [pasteNotice, setPasteNotice] = useState<string | null>(null);

  const sampleUrls = [
    {
      label: "Direct MP4 (Flower Sample)",
      url: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      tag: "Direct MP4",
      color: "bg-emerald-950/40 text-emerald-300 border-emerald-800/40",
    },
    {
      label: "Direct WebM (Big Buck Bunny)",
      url: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.360p.vp9.webm",
      tag: "Direct Video",
      color: "bg-teal-950/40 text-teal-300 border-teal-800/40",
    },
    {
      label: "YouTube Video",
      url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
      tag: "YouTube",
      color: "bg-red-950/40 text-red-300 border-red-800/40",
    },
    {
      label: "Facebook Watch",
      url: "https://fb.watch/example-video-id/",
      tag: "Facebook",
      color: "bg-blue-950/40 text-blue-300 border-blue-800/40",
    },
    {
      label: "Pinterest Pin",
      url: "https://pin.it/7xTestPin",
      tag: "Pinterest",
      color: "bg-rose-950/40 text-rose-300 border-rose-800/40",
    },
  ];

  const handlePaste = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          onUrlChange(text.trim());
          setPasteNotice(language === "bn" ? "ক্লিপবোর্ড থেকে পেস্ট করা হয়েছে!" : "Pasted from clipboard!");
          setTimeout(() => setPasteNotice(null), 2500);
          return;
        }
      }
      // If clipboard read is empty or restricted
      const fallback = window.prompt(
        language === "bn"
          ? "দয়া করে আপনার ভিডিও লিংকটি এখানে পেস্ট করুন:"
          : "Please paste your video link here:"
      );
      if (fallback) {
        onUrlChange(fallback.trim());
      }
    } catch {
      const fallback = window.prompt(
        language === "bn"
          ? "ক্লিপবোর্ড অ্যাক্সেস অনুমোদিত নয়। দয়া করে আপনার লিংকটি এখানে পেস্ট করুন:"
          : "Clipboard access was not granted. Please paste your link manually:"
      );
      if (fallback) {
        onUrlChange(fallback.trim());
      }
    }
  };

  const getPlaceholder = () => {
    switch (selectedPlatform) {
      case "direct":
        return "https://example.com/video.mp4";
      case "youtube":
        return "https://youtube.com/watch?v=... or https://youtu.be/...";
      case "facebook":
        return "https://facebook.com/... or https://fb.watch/...";
      case "pinterest":
        return "https://pinterest.com/pin/... or https://pin.it/...";
      default:
        return language === "bn"
          ? "এখানে ভিডিও বা সোশ্যাল মিডিয়ার লিংক পেস্ট করুন..."
          : "Paste direct MP4, YouTube, Facebook, or Pinterest URL...";
    }
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
      {/* Input container */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
          <span>{language === "bn" ? "ভিডিও লিংক (URL)" : "Video Link (URL)"}</span>
          {pasteNotice && (
            <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-normal animate-fade-in">
              <CheckCircle2 className="w-3 h-3" />
              {pasteNotice}
            </span>
          )}
        </label>

        <div className="relative flex items-center">
          <input
            type="url"
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && url.trim()) {
                onValidate();
              }
            }}
            placeholder={getPlaceholder()}
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl py-3.5 pl-3.5 pr-20 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all font-mono"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="none"
            spellCheck="false"
          />

          <div className="absolute right-1.5 flex items-center space-x-1">
            {url && (
              <button
                type="button"
                onClick={() => onUrlChange("")}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="Clear input"
                aria-label="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={handlePaste}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-medium active:scale-95 transition-all"
              title="Paste from clipboard"
            >
              <Clipboard className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">{language === "bn" ? "পেস্ট" : "Paste"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Action button: Validate Link */}
      <button
        type="button"
        onClick={onValidate}
        disabled={!url.trim() || isValidating}
        className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-lg shadow-indigo-950/50 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed min-h-[48px]"
      >
        <Search className="w-4 h-4" />
        <span>
          {isValidating
            ? language === "bn"
              ? "যাচাই করা হচ্ছে..."
              : "Validating Link..."
            : language === "bn"
            ? "লিংক যাচাই করুন (Validate Link)"
            : "Validate Link"}
        </span>
      </button>

      {/* Sample Quick Links for Android Testing */}
      <div className="pt-2 border-t border-slate-800/80">
        <div className="flex items-center gap-1.5 mb-2 text-[11px] text-slate-400">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>
            {language === "bn"
              ? "টেস্টিংয়ের জন্য দ্রুত স্যাম্পল লিংক নির্বাচন করুন:"
              : "Quick sample links to test on Android:"}
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {sampleUrls.map((s, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onUrlChange(s.url)}
              className={`text-[11px] px-2.5 py-1.5 rounded-lg border font-medium transition-all active:scale-95 ${s.color} hover:brightness-125`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
