"use client";

import React from "react";
import { Download, Cpu, Globe2, ShieldCheck } from "lucide-react";

interface HeaderProps {
  language: "en" | "bn";
  onLanguageChange: (lang: "en" | "bn") => void;
}

export const Header: React.FC<HeaderProps> = ({ language, onLanguageChange }) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-sm">
      <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo and Title */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-emerald-400 p-0.5 shadow-md flex items-center justify-center">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center text-emerald-400">
              <Download className="w-5 h-5 stroke-[2.5]" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold tracking-tight text-white">Video Saver</h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                v2.1
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>{language === "bn" ? "নিরাপদ মোবাইল ডাউনলোডার" : "Safe Mobile Downloader"}</span>
            </p>
          </div>
        </div>

        {/* Right side: RAM info & Language toggle */}
        <div className="flex items-center space-x-2">
          {/* 4GB RAM Badge */}
          <div className="hidden xs:flex items-center gap-1 text-[11px] font-medium bg-slate-800/80 text-slate-300 px-2 py-1 rounded-full border border-slate-700">
            <Cpu className="w-3 h-3 text-indigo-400" />
            <span>4 GB RAM Safe</span>
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => onLanguageChange(language === "en" ? "bn" : "en")}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600/30 hover:bg-indigo-600/40 text-indigo-200 border border-indigo-500/30 transition-all active:scale-95"
            title="Switch Language / ভাষা পরিবর্তন করুন"
            aria-label="Toggle language"
          >
            <Globe2 className="w-3.5 h-3.5 text-indigo-300" />
            <span>{language === "en" ? "বাংলা" : "English"}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
