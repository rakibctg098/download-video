"use client";

import React from "react";
import { DownloadProgressState } from "@/types";
import { Loader2, XCircle, CheckCircle2, ArrowDownCircle } from "lucide-react";

interface RealProgressBarProps {
  progress: DownloadProgressState;
  onCancel?: () => void;
  language: "en" | "bn";
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export const RealProgressBar: React.FC<RealProgressBarProps> = ({
  progress,
  onCancel,
  language,
}) => {
  const {
    isDownloading,
    downloadedBytes,
    totalBytes,
    percentage,
    speedBytesPerSec,
    statusText,
    statusTextBn,
    error,
  } = progress;

  if (!isDownloading && !error && downloadedBytes === 0) {
    return null;
  }

  const isCompleted = percentage === 100 && !isDownloading && !error;
  const isIndeterminate = isDownloading && (totalBytes === null || totalBytes === 0);

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
      {/* Top Status Row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {isDownloading ? (
            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
          ) : isCompleted ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          ) : error ? (
            <XCircle className="w-4 h-4 text-red-400" />
          ) : (
            <ArrowDownCircle className="w-4 h-4 text-slate-400" />
          )}

          <div>
            <h4 className="text-sm font-semibold text-white">
              {language === "bn" ? statusTextBn || statusText : statusText}
            </h4>
            {isDownloading && (
              <p className="text-xs text-slate-400">
                {language === "bn"
                  ? "সত্যিকারের প্রগ্রেস (কোনো ডামি ডেটা নয়)"
                  : "Genuine measurable byte stream"}
              </p>
            )}
          </div>
        </div>

        {/* Speed / Cancel */}
        <div className="flex items-center space-x-2">
          {isDownloading && speedBytesPerSec > 0 && (
            <span className="text-xs font-mono font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full">
              {formatBytes(speedBytesPerSec)}/s
            </span>
          )}

          {isDownloading && onCancel && (
            <button
              onClick={onCancel}
              className="text-xs px-2.5 py-1 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 border border-red-800/60 transition-all active:scale-95"
            >
              {language === "bn" ? "বাতিল" : "Cancel"}
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar Container */}
      <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden relative">
        {isIndeterminate ? (
          /* Real stream without Content-Length: show animated indeterminate sweep */
          <div className="h-full bg-gradient-to-r from-indigo-500 via-emerald-400 to-indigo-500 rounded-full w-2/3 animate-pulse" />
        ) : (
          /* Measurable stream */
          <div
            className={`h-full transition-all duration-150 ease-out rounded-full ${
              isCompleted
                ? "bg-emerald-500"
                : error
                ? "bg-red-500"
                : "bg-gradient-to-r from-indigo-500 to-emerald-400"
            }`}
            style={{ width: `${Math.min(100, Math.max(0, percentage ?? 0))}%` }}
          />
        )}
      </div>

      {/* Bytes breakdown */}
      <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-0.5">
        <span>
          {formatBytes(downloadedBytes)}
          {totalBytes ? ` / ${formatBytes(totalBytes)}` : " (Indeterminate size)"}
        </span>
        <span>
          {percentage !== null ? `${percentage.toFixed(1)}%` : "Streaming..."}
        </span>
      </div>

      {/* Notice for indeterminate streams */}
      {isIndeterminate && (
        <div className="text-[11px] text-amber-300/90 bg-amber-950/30 border border-amber-800/40 rounded-xl p-2.5">
          {language === "bn"
            ? "⚠️ সার্ভার মোট ফাইলের আকার (Content-Length) সরবরাহ করেনি, তাই ব্যাকগ্রাউন্ডে স্ট্রিম হিসেবে ডাউনলোড হচ্ছে।"
            : "⚠️ Remote server did not provide a Content-Length header. Streaming in real-time until completion."}
        </div>
      )}

      {/* Error message */}
      {error && (
        <div className="text-xs text-red-300 bg-red-950/40 border border-red-800/50 rounded-xl p-2.5">
          {error}
        </div>
      )}
    </div>
  );
};
