"use client";

import React from "react";
import { AppSettings, DownloadEngine } from "@/types";
import { Settings, ShieldCheck, Cpu, HardDrive, FileText, Check } from "lucide-react";

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  language: "en" | "bn";
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  language,
}) => {
  return (
    <div className="space-y-4">
      {/* Title */}
      <div>
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-400" />
          <span>{language === "bn" ? "অ্যাপ সেটিংস" : "Application Settings"}</span>
        </h2>
        <p className="text-xs text-slate-400">
          {language === "bn"
            ? "আপনার ডিভাইসের সুবিধা অনুযায়ী ডাউনলোড ও ব্রাউজার অপশন কনফিগার করুন"
            : "Configure download preferences and Android memory safeguards"}
        </p>
      </div>

      {/* 4GB RAM Android Safety Status Card */}
      <div className="bg-emerald-950/30 border border-emerald-800/40 rounded-2xl p-4 space-y-2">
        <div className="flex items-center gap-2 text-emerald-300 font-semibold text-xs">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <span>
            {language === "bn"
              ? "অ্যান্ড্রয়েড ৪ জিবি র‍্যাম সেফটি মোড সক্রিয়"
              : "Android 4 GB RAM Optimization Active"}
          </span>
        </div>
        <p className="text-[11px] text-emerald-200/80 leading-relaxed">
          {language === "bn"
            ? "ফাইল ডাউনলোডের সময় মেমোরি অতিরিক্ত ব্যবহার না করতে চাঙ্ক ভিত্তিক স্ট্রিমিং ব্যবহার করা হয়, যাতে আপনার ফোন হ্যাং বা রিস্টার্ট না হয়।"
            : "Chunk-based streaming ensures downloads never exceed mobile memory boundaries on 4 GB RAM devices running Android 12 or 13."}
        </p>
      </div>

      {/* Settings Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4 shadow-xl">
        {/* Download Engine Preference */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-indigo-400" />
            <span>{language === "bn" ? "ডাউনলোড ইঞ্জিন মোড" : "Download Engine Mode"}</span>
          </label>

          <div className="grid grid-cols-1 gap-2">
            {[
              {
                id: "smart_stream" as DownloadEngine,
                title: language === "bn" ? "স্মার্ট স্ট্রিমিং (Smart Stream)" : "Smart Stream with Real Progress",
                desc:
                  language === "bn"
                    ? "রিয়েল-টাইম গতি ও মেগাবাইট প্রগ্রেস বার প্রদর্শন করে (প্রস্তাবিত)।"
                    : "Measures byte chunks and displays genuine real-time progress bar.",
              },
              {
                id: "direct_link" as DownloadEngine,
                title: language === "bn" ? "ক্রোম নেটিভ ডাউনলোড (Native Download)" : "Direct Chrome Native Download",
                desc:
                  language === "bn"
                    ? "সরাসরি ব্রাউজারের নিজস্ব ডাউনলোড ম্যানেজারে পাঠায় (খুব বড় ফাইলের জন্য সেরা)।"
                    : "Uses Chrome's native download manager directly; best for large files.",
              },
              {
                id: "server_proxy" as DownloadEngine,
                title: language === "bn" ? "সার্ভার স্ট্রিম (Server Stream)" : "Server-Assisted Stream",
                desc:
                  language === "bn"
                    ? "যদি কোনো ডিরেক্ট ভিডিও ফাইলে ব্রাউজার CORS সমস্যা দেখা দেয়।"
                    : "Assists when strict CORS headers prevent direct in-browser fetching.",
              },
            ].map((engine) => (
              <div
                key={engine.id}
                onClick={() => onUpdateSettings({ downloadEngine: engine.id })}
                className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                  settings.downloadEngine === engine.id
                    ? "bg-indigo-950/60 border-indigo-500 text-white shadow-sm ring-1 ring-indigo-500"
                    : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span>{engine.title}</span>
                  {settings.downloadEngine === engine.id && (
                    <Check className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{engine.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Custom Filename Prefix */}
        <div className="space-y-1.5 pt-2 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-indigo-400" />
            <span>{language === "bn" ? "ফাইলের নামের প্রিফিক্স" : "Filename Prefix"}</span>
          </label>
          <input
            type="text"
            value={settings.filenamePrefix}
            onChange={(e) => onUpdateSettings({ filenamePrefix: e.target.value })}
            placeholder="VideoSaver_"
            className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
          <p className="text-[11px] text-slate-500">
            {language === "bn"
              ? "ডাউনলোডকৃত ফাইলটি এই প্রিফিক্স দিয়ে শুরু হবে (যেমন: VideoSaver_clip.mp4)"
              : "Downloaded files will be saved with this prefix for easy searching."}
          </p>
        </div>

        {/* Auto Validate on Paste */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <div>
            <h4 className="text-xs font-semibold text-slate-200">
              {language === "bn" ? "পেস্ট করার সাথে সাথে স্বয়ংক্রিয় যাচাই" : "Auto-Validate on Paste"}
            </h4>
            <p className="text-[11px] text-slate-400">
              {language === "bn"
                ? "পেস্ট বাটনে চাপলে সরাসরি লিংক বিশ্লেষণ শুরু হবে"
                : "Automatically trigger URL analysis when pasting a link"}
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              onUpdateSettings({ autoValidateOnPaste: !settings.autoValidateOnPaste })
            }
            className={`w-11 h-6 rounded-full p-1 transition-colors ${
              settings.autoValidateOnPaste ? "bg-indigo-600" : "bg-slate-700"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                settings.autoValidateOnPaste ? "translate-x-5" : "translate-x-0"
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
