"use client";

import React from "react";
import { ActiveTab } from "@/types";
import { Download, History, FlaskConical, Settings, HelpCircle } from "lucide-react";

interface BottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  language: "en" | "bn";
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  language,
}) => {
  const tabs = [
    {
      id: "saver" as ActiveTab,
      label: language === "bn" ? "সেভার" : "Saver",
      icon: Download,
    },
    {
      id: "history" as ActiveTab,
      label: language === "bn" ? "হিস্টোরি" : "History",
      icon: History,
    },
    {
      id: "tests" as ActiveTab,
      label: language === "bn" ? "টেস্ট" : "Tests",
      icon: FlaskConical,
    },
    {
      id: "settings" as ActiveTab,
      label: language === "bn" ? "সেটিংস" : "Settings",
      icon: Settings,
    },
    {
      id: "help" as ActiveTab,
      label: language === "bn" ? "গাইড" : "Guide",
      icon: HelpCircle,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 shadow-2xl">
      <div className="max-w-2xl mx-auto px-2 flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-2 px-2 min-h-[56px] min-w-[56px] transition-all relative ${
                isActive ? "text-indigo-400 font-semibold" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {isActive && (
                <span className="absolute top-0 w-8 h-1 bg-indigo-500 rounded-b-full shadow-sm shadow-indigo-500/50" />
              )}
              <Icon
                className={`w-5 h-5 transition-transform ${
                  isActive ? "scale-110 text-indigo-400" : "text-slate-400"
                }`}
              />
              <span className="text-[10px] mt-1 leading-none">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
