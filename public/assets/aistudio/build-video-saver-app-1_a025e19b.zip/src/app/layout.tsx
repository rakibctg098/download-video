import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: "#020617",
};

export const metadata: Metadata = {
  title: "Video Saver - Mobile Web Video Downloader",
  description:
    "Mobile-first video saver and link analyzer for Android Chrome. Real byte-accurate downloads for direct MP4 media with safe platform classification.",
  keywords: ["video saver", "mp4 downloader", "android chrome video download", "media analyzer"],
  authors: [{ name: "Video Saver Team" }],
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-indigo-600/40 selection:text-white">
        {children}
      </body>
    </html>
  );
}
