"use client";

import React, { useState, useEffect, useRef } from "react";
import { Header } from "@/components/Header";
import { PlatformSelector, PlatformFilter } from "@/components/PlatformSelector";
import { UrlInputSection } from "@/components/UrlInputSection";
import { VideoInfoCard } from "@/components/VideoInfoCard";
import { RealProgressBar } from "@/components/RealProgressBar";
import { AndroidStorageNotice } from "@/components/AndroidStorageNotice";
import { HistoryView } from "@/components/HistoryView";
import { TestSuiteView } from "@/components/TestSuiteView";
import { SettingsView } from "@/components/SettingsView";
import { HelpView } from "@/components/HelpView";
import { BottomNav } from "@/components/BottomNav";
import { ActiveTab, AppSettings, DownloadProgressState, VideoMetadata } from "@/types";
import { analyzeUrl } from "@/lib/urlClassifier";
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Info,
  Shield,
  Smartphone,
  ExternalLink,
  Download,
} from "lucide-react";

const DEFAULT_SETTINGS: AppSettings = {
  downloadEngine: "smart_stream",
  filenamePrefix: "VideoSaver_",
  autoValidateOnPaste: true,
  maxSizeBytes: 100 * 1024 * 1024,
  language: "bn",
};

export default function Home() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("saver");
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [language, setLanguage] = useState<"en" | "bn">("bn");

  // Saver state
  const [url, setUrl] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformFilter>("all");
  const [isValidating, setIsValidating] = useState(false);
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);

  // Feedback banner
  const [feedback, setFeedback] = useState<{
    type: "success" | "warning" | "error" | "info";
    message: string;
    messageBn: string;
  } | null>(null);

  // Download state
  const [progress, setProgress] = useState<DownloadProgressState>({
    isDownloading: false,
    downloadedBytes: 0,
    totalBytes: null,
    percentage: null,
    speedBytesPerSec: 0,
    statusText: "",
    statusTextBn: "",
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  // Load saved settings from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("videosaver_settings");
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings((prev) => ({ ...prev, ...parsed }));
        if (parsed.language) {
          setLanguage(parsed.language);
        }
      }
    } catch {
      // Ignore localStorage errors
    }
  }, []);

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem("videosaver_settings", JSON.stringify(updated));
      } catch {
        // Ignore
      }
      return updated;
    });
  };

  const handleLanguageChange = (lang: "en" | "bn") => {
    setLanguage(lang);
    updateSettings({ language: lang });
  };

  // URL Change handler
  const handleUrlChange = (newUrl: string) => {
    setUrl(newUrl);
    setMetadata(null);
    setFeedback(null);

    // Auto-detect platform when typing
    if (newUrl.trim()) {
      const parsed = analyzeUrl(newUrl);
      if (parsed.platform === "youtube") setSelectedPlatform("youtube");
      else if (parsed.platform === "facebook") setSelectedPlatform("facebook");
      else if (parsed.platform === "pinterest") setSelectedPlatform("pinterest");
      else if (parsed.isDirectMediaCandidate) setSelectedPlatform("direct");
    }
  };

  // Record history helper
  const recordHistory = async (params: {
    url: string;
    title: string;
    platform: string;
    contentType?: string | null;
    fileSizeBytes?: number | null;
    status: string;
    downloadMethod?: string;
  }) => {
    try {
      await fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
    } catch (e) {
      console.warn("Could not record history in DB:", e);
    }
  };

  // Validate Link
  const handleValidate = async () => {
    const trimmed = url.trim();
    if (!trimmed) {
      setFeedback({
        type: "warning",
        message: "Please enter a valid URL first.",
        messageBn: "অনুগ্রহ করে প্রথমে একটি লিংক দিন।",
      });
      return;
    }

    // Client-side quick scheme validation
    const quickAnalysis = analyzeUrl(trimmed);
    if (!quickAnalysis.isValid) {
      setFeedback({
        type: "error",
        message: quickAnalysis.limitationReason || "Invalid URL syntax.",
        messageBn: quickAnalysis.guidanceTextBn,
      });
      return;
    }

    try {
      setIsValidating(true);
      setFeedback(null);

      const res = await fetch("/api/probe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: trimmed }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setFeedback({
          type: "error",
          message: data.message || data.error || "Failed to inspect URL headers.",
          messageBn: data.messageBn || "লিংকটি যাচাই করা সম্ভব হয়নি।",
        });
        if (data.platform) {
          setMetadata(data as VideoMetadata);
        }
        return;
      }

      const meta = data as VideoMetadata;

      // Apply custom filename prefix if direct media
      if (meta.isDirectMedia && settings.filenamePrefix) {
        if (!meta.filename.startsWith(settings.filenamePrefix)) {
          meta.filename = `${settings.filenamePrefix}${meta.filename}`;
        }
      }

      setMetadata(meta);

      if (meta.canDownloadInBrowser) {
        setFeedback({
          type: "success",
          message: "Valid video stream detected! Tap 'Download Video' to save to your Android device.",
          messageBn: "সঠিক ভিডিও ফাইল শনাক্ত হয়েছে! ফোনে সেভ করতে 'ভিডিও ডাউনলোড করুন' চাপুন।",
        });
      } else if (meta.category === "social_media") {
        setFeedback({
          type: "info",
          message: meta.message,
          messageBn: meta.messageBn,
        });

        // Record social visit
        recordHistory({
          url: trimmed,
          title: meta.title,
          platform: meta.platform,
          contentType: meta.contentType,
          status: "social_opened",
          downloadMethod: "external",
        });
      } else {
        setFeedback({
          type: "warning",
          message: meta.message,
          messageBn: meta.messageBn,
        });
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : "Network error";
      setFeedback({
        type: "error",
        message: `Validation failed: ${errMsg}. Check your connection and retry.`,
        messageBn: `যাচাই ব্যর্থ হয়েছে: ${errMsg}। ইন্টারনেট কানেকশন চেক করুন।`,
      });
    } finally {
      setIsValidating(false);
    }
  };

  // Cancel in-flight download
  const handleCancelDownload = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setProgress((prev) => ({
      ...prev,
      isDownloading: false,
      statusText: "Download canceled by user.",
      statusTextBn: "ডাউনলোড বাতিল করা হয়েছে।",
      error: language === "bn" ? "ডাউনলোড বাতিল করা হয়েছে।" : "Download canceled by user.",
    }));
  };

  // Trigger Real Download
  const handleDownload = async () => {
    if (!metadata || !metadata.canDownloadInBrowser) {
      setFeedback({
        type: "warning",
        message: "Please validate a downloadable direct media file first.",
        messageBn: "অনুগ্রহ করে প্রথমে একটি সঠিক মিডিয়া ফাইল যাচাই করুন।",
      });
      return;
    }

    const downloadTargetUrl = metadata.url;
    const finalFilename = metadata.filename || "VideoSaver_video.mp4";

    // Mode 1: Direct Browser Download (Native Chrome Download Manager)
    if (settings.downloadEngine === "direct_link") {
      const a = document.createElement("a");
      a.href = downloadTargetUrl;
      a.download = finalFilename;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setFeedback({
        type: "success",
        message: `Download triggered via Android Chrome. Check notifications for '${finalFilename}'.`,
        messageBn: `ক্রোম ব্রাউজারে ডাউনলোড শুরু হয়েছে। নোটিফিকেশন চেক করুন: '${finalFilename}'।`,
      });

      recordHistory({
        url: downloadTargetUrl,
        title: metadata.title,
        platform: metadata.platform,
        contentType: metadata.contentType,
        fileSizeBytes: metadata.contentLength,
        status: "completed",
        downloadMethod: "browser_link",
      });
      return;
    }

    // Mode 2 & 3: Smart Stream with Real Byte Progress
    abortControllerRef.current = new AbortController();
    const { signal } = abortControllerRef.current;

    setProgress({
      isDownloading: true,
      downloadedBytes: 0,
      totalBytes: metadata.contentLength || null,
      percentage: metadata.contentLength ? 0 : null,
      speedBytesPerSec: 0,
      statusText: "Connecting to media stream...",
      statusTextBn: "ভিডিও স্ট্রিমের সাথে সংযোগ করা হচ্ছে...",
      error: undefined,
    });

    // Determine fetch URL: If server_proxy mode, fetch via API; otherwise direct fetch
    let fetchUrl = downloadTargetUrl;
    if (settings.downloadEngine === "server_proxy") {
      fetchUrl = `/api/stream-download?url=${encodeURIComponent(
        downloadTargetUrl
      )}&filename=${encodeURIComponent(finalFilename)}`;
    }

    try {
      let response: Response;
      try {
        response = await fetch(fetchUrl, {
          signal,
          headers: { Accept: "*/*" },
        });
      } catch (clientFetchErr) {
        // If direct client fetch failed due to CORS, seamlessly try server stream proxy
        if (settings.downloadEngine === "smart_stream") {
          console.info("Direct CORS fetch restricted. Switching to server stream fallback...");
          setProgress((prev) => ({
            ...prev,
            statusText: "Bypassing CORS via server stream...",
            statusTextBn: "সার্ভার স্ট্রিমের মাধ্যমে ডাউনলোড চালানো হচ্ছে...",
          }));
          const fallbackUrl = `/api/stream-download?url=${encodeURIComponent(
            downloadTargetUrl
          )}&filename=${encodeURIComponent(finalFilename)}`;
          response = await fetch(fallbackUrl, { signal });
        } else {
          throw clientFetchErr;
        }
      }

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status} (${response.statusText})`);
      }

      if (!response.body) {
        throw new Error("Empty response body from media server.");
      }

      // Check header length
      const headerLength = response.headers.get("content-length");
      const totalBytes = headerLength ? parseInt(headerLength, 10) : metadata.contentLength;

      const reader = response.body.getReader();
      const chunks: BlobPart[] = [];
      let receivedBytes = 0;
      let lastTime = performance.now();
      let lastBytes = 0;
      let currentSpeed = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        if (value) {
          chunks.push(value);
          receivedBytes += value.length;

          const now = performance.now();
          const elapsed = (now - lastTime) / 1000;
          if (elapsed >= 0.3) {
            const bytesDelta = receivedBytes - lastBytes;
            currentSpeed = Math.round(bytesDelta / elapsed);
            lastTime = now;
            lastBytes = receivedBytes;

            const calcPercentage = totalBytes ? (receivedBytes / totalBytes) * 100 : null;

            setProgress({
              isDownloading: true,
              downloadedBytes: receivedBytes,
              totalBytes,
              percentage: calcPercentage,
              speedBytesPerSec: currentSpeed,
              statusText: "Streaming video chunks...",
              statusTextBn: "ভিডিও ফাইল ডাউনলোড হচ্ছে...",
            });
          }
        }
      }

      // Download complete: assemble blob
      setProgress((prev) => ({
        ...prev,
        isDownloading: false,
        downloadedBytes: receivedBytes,
        totalBytes: receivedBytes,
        percentage: 100,
        speedBytesPerSec: 0,
        statusText: "Download complete! Saving to Android...",
        statusTextBn: "ডাউনলোড সম্পন্ন! ফোনে সেভ করা হচ্ছে...",
      }));

      const mimeType = metadata.contentType || "video/mp4";
      const blob = new Blob(chunks, { type: mimeType });
      const blobUrl = URL.createObjectURL(blob);

      // Trigger browser file download
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = finalFilename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // Free memory on 4GB RAM phone after a short timeout
      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 10000);

      setFeedback({
        type: "success",
        message: `Saved '${finalFilename}'! Find it in your Android Downloads folder.`,
        messageBn: `'${finalFilename}' ডাউনলোড হয়েছে! আপনার ফোনের 'Downloads' ফোল্ডারে দেখতে পাবেন।`,
      });

      // Record to history
      recordHistory({
        url: downloadTargetUrl,
        title: metadata.title,
        platform: metadata.platform,
        contentType: mimeType,
        fileSizeBytes: receivedBytes,
        status: "completed",
        downloadMethod: settings.downloadEngine,
      });
    } catch (err) {
      if (signal.aborted) {
        return; // Handled in cancel
      }

      const errMsg = err instanceof Error ? err.message : "Download failed";
      setProgress({
        isDownloading: false,
        downloadedBytes: 0,
        totalBytes: null,
        percentage: null,
        speedBytesPerSec: 0,
        statusText: "Download failed",
        statusTextBn: "ডাউনলোড ব্যর্থ হয়েছে",
        error: errMsg,
      });

      setFeedback({
        type: "error",
        message: `Download failed: ${errMsg}. You can use the 'Chrome Native Download' button below to download directly.`,
        messageBn: `ডাউনলোড ত্রুটি: ${errMsg}। ব্রাউজার থেকে সরাসরি সেভ করতে নিচের 'ক্রোম সরাসরি ডাউনলোড' বাটন ব্যবহার করুন।`,
      });

      recordHistory({
        url: downloadTargetUrl,
        title: metadata.title,
        platform: metadata.platform,
        status: "failed",
        downloadMethod: settings.downloadEngine,
      });
    } finally {
      abortControllerRef.current = null;
    }
  };

  // From History or Test Suite: Load test URL
  const handleLoadUrlFromExternal = (newUrl: string) => {
    setUrl(newUrl);
    setActiveTab("saver");
    handleUrlChange(newUrl);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col pb-24 selection:bg-indigo-500/30 font-sans">
      {/* Top App Header */}
      <Header language={language} onLanguageChange={handleLanguageChange} />

      {/* Main Container */}
      <main className="flex-1 max-w-2xl w-full mx-auto px-4 py-4 space-y-4">
        {/* SAVER TAB */}
        {activeTab === "saver" && (
          <div className="space-y-4 animate-fade-in">
            {/* Feedback Banner */}
            {feedback && (
              <div
                className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 shadow-md transition-all ${
                  feedback.type === "success"
                    ? "bg-emerald-950/40 border-emerald-800/60 text-emerald-200"
                    : feedback.type === "error"
                    ? "bg-red-950/40 border-red-800/60 text-red-200"
                    : feedback.type === "warning"
                    ? "bg-amber-950/40 border-amber-800/60 text-amber-200"
                    : "bg-blue-950/40 border-blue-800/60 text-blue-200"
                }`}
              >
                {feedback.type === "success" ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : feedback.type === "error" ? (
                  <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                ) : feedback.type === "warning" ? (
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                )}
                <div className="space-y-0.5">
                  <p className="font-semibold">
                    {language === "bn" ? feedback.messageBn : feedback.message}
                  </p>
                </div>
              </div>
            )}

            {/* Platform Selector */}
            <PlatformSelector
              selected={selectedPlatform}
              onSelect={(p) => setSelectedPlatform(p)}
              language={language}
            />

            {/* URL Input Area */}
            <UrlInputSection
              url={url}
              onUrlChange={handleUrlChange}
              onValidate={handleValidate}
              isValidating={isValidating}
              selectedPlatform={selectedPlatform}
              language={language}
            />

            {/* Real Progress Bar */}
            <RealProgressBar
              progress={progress}
              onCancel={handleCancelDownload}
              language={language}
            />

            {/* Video Information Card */}
            {metadata && (
              <VideoInfoCard
                metadata={metadata}
                onDownload={handleDownload}
                isDownloading={progress.isDownloading}
                language={language}
              />
            )}

            {/* Android Storage & File Saving Notice */}
            <AndroidStorageNotice language={language} />

            {/* Beginner Quick Guide Pill */}
            <div
              onClick={() => setActiveTab("help")}
              className="bg-indigo-950/30 hover:bg-indigo-950/50 border border-indigo-800/40 rounded-2xl p-3.5 flex items-center justify-between text-xs text-indigo-300 cursor-pointer transition-all active:scale-[0.99]"
            >
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-white">
                    {language === "bn"
                      ? "প্রথমবার ব্যবহার করছেন? সহজ বাংলা গাইড দেখুন"
                      : "New beginner on Android? View step-by-step guide"}
                  </p>
                  <p className="text-[11px] text-indigo-300/80">
                    {language === "bn"
                      ? "ডাউনলোড, Movies ফোল্ডার ও গ্যালারির বিস্তারিত নিয়ম"
                      : "Find files in Downloads and move to Movies/VideoSaver"}
                  </p>
                </div>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-600/30 text-indigo-200">
                {language === "bn" ? "গাইড খুলুন" : "Open"}
              </span>
            </div>
          </div>
        )}

        {/* HISTORY TAB */}
        {activeTab === "history" && (
          <div className="animate-fade-in">
            <HistoryView
              onSelectUrlForDownload={handleLoadUrlFromExternal}
              language={language}
            />
          </div>
        )}

        {/* TEST SUITE TAB */}
        {activeTab === "tests" && (
          <div className="animate-fade-in">
            <TestSuiteView
              onLoadTestUrl={handleLoadUrlFromExternal}
              language={language}
            />
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === "settings" && (
          <div className="animate-fade-in">
            <SettingsView
              settings={settings}
              onUpdateSettings={updateSettings}
              language={language}
            />
          </div>
        )}

        {/* HELP & BEGINNER GUIDE TAB */}
        {activeTab === "help" && (
          <div className="animate-fade-in">
            <HelpView language={language} />
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        language={language}
      />
    </div>
  );
}
