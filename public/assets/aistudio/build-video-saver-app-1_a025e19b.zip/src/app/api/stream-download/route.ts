import { NextRequest, NextResponse } from "next/server";
import { validateUrlForSsrf } from "@/lib/ssrfProtection";
import { analyzeUrl } from "@/lib/urlClassifier";

// Maximum stream size: 100 MB for Android 4GB RAM safety
const MAX_ALLOWED_BYTES = 100 * 1024 * 1024;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const targetUrl = searchParams.get("url");
  const customFilename = searchParams.get("filename");

  if (!targetUrl) {
    return new NextResponse("Missing url parameter", { status: 400 });
  }

  // 1. Structure check
  const analysis = analyzeUrl(targetUrl);
  if (!analysis.isValid) {
    return new NextResponse(`Invalid URL: ${analysis.limitationReason}`, { status: 400 });
  }

  // Reject social media pages from being fetched through server stream
  if (analysis.category === "social_media") {
    return new NextResponse(
      "Social media post pages (YouTube, Facebook, Pinterest) cannot be downloaded via server stream. Use direct video file URLs.",
      { status: 400 }
    );
  }

  // 2. SSRF check
  const ssrf = validateUrlForSsrf(targetUrl);
  if (!ssrf.isSafe) {
    return new NextResponse(`Access denied by SSRF protection: ${ssrf.reason}`, { status: 403 });
  }

  try {
    // 3. Initiate upstream request with stream
    const upstreamRes = await fetch(targetUrl, {
      method: "GET",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 VideoSaver/1.0",
        Accept: "*/*",
      },
      signal: AbortSignal.timeout(30000), // 30s timeout
    });

    if (!upstreamRes.ok) {
      return new NextResponse(
        `Upstream server returned error status ${upstreamRes.status} (${upstreamRes.statusText})`,
        { status: 502 }
      );
    }

    const contentType = upstreamRes.headers.get("content-type") || "video/mp4";
    const contentLength = upstreamRes.headers.get("content-length");

    // Don't proxy HTML pages disguised as videos
    if (contentType.toLowerCase().includes("text/html")) {
      return new NextResponse(
        "Target URL returned text/html instead of a video stream. It is a webpage, not a video file.",
        { status: 422 }
      );
    }

    // Check size limit if known
    if (contentLength) {
      const bytes = parseInt(contentLength, 10);
      if (!isNaN(bytes) && bytes > MAX_ALLOWED_BYTES) {
        return new NextResponse(
          `File size (${(bytes / (1024 * 1024)).toFixed(1)} MB) exceeds mobile safety limit of 100 MB.`,
          { status: 413 }
        );
      }
    }

    if (!upstreamRes.body) {
      return new NextResponse("Empty response body from upstream server", { status: 502 });
    }

    // Determine filename
    let filename = customFilename ? customFilename.trim() : analysis.suggestedFilename;
    if (!filename.includes(".")) {
      filename += ".mp4";
    }
    // Sanitize filename
    const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, "_");

    // Construct response headers
    const responseHeaders = new Headers();
    responseHeaders.set("Content-Type", contentType);
    responseHeaders.set("Content-Disposition", `attachment; filename="${safeFilename}"`);
    if (contentLength) {
      responseHeaders.set("Content-Length", contentLength);
    }
    responseHeaders.set("Cache-Control", "no-cache, no-transform");

    // Directly pipe the upstream stream without buffering the entire file in RAM
    return new NextResponse(upstreamRes.body as BodyInit, {
      status: 200,
      headers: responseHeaders,
    });
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : "Stream fetch failed";
    return new NextResponse(`Error downloading media stream: ${errorMsg}`, { status: 500 });
  }
}
