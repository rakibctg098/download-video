import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { downloadHistory } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const items = await db
      .select()
      .from(downloadHistory)
      .orderBy(desc(downloadHistory.createdAt))
      .limit(100);

    return NextResponse.json({ success: true, items });
  } catch (err) {
    console.error("Failed to fetch history:", err);
    return NextResponse.json(
      { success: false, error: "Failed to fetch download history", items: [] },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { url, title, platform, contentType, fileSizeBytes, status, downloadMethod, notes } = body;

    if (!url || !title) {
      return NextResponse.json(
        { success: false, error: "Missing required fields url or title" },
        { status: 400 }
      );
    }

    const [newItem] = await db
      .insert(downloadHistory)
      .values({
        url,
        title: title.slice(0, 255),
        platform: platform || "unknown",
        contentType: contentType || null,
        fileSizeBytes: typeof fileSizeBytes === "number" ? fileSizeBytes : null,
        status: status || "completed",
        downloadMethod: downloadMethod || "client_stream",
        notes: notes || null,
      })
      .returning();

    return NextResponse.json({ success: true, item: newItem }, { status: 201 });
  } catch (err) {
    console.error("Failed to create history record:", err);
    return NextResponse.json(
      { success: false, error: "Failed to record history" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const parsedId = parseInt(id, 10);
      if (!isNaN(parsedId)) {
        await db.delete(downloadHistory).where(eq(downloadHistory.id, parsedId));
        return NextResponse.json({ success: true, deletedId: parsedId });
      }
    }

    // If no id provided, clear all history
    await db.delete(downloadHistory);
    return NextResponse.json({ success: true, message: "History cleared successfully" });
  } catch (err) {
    console.error("Failed to delete history:", err);
    return NextResponse.json(
      { success: false, error: "Failed to delete history items" },
      { status: 500 }
    );
  }
}
