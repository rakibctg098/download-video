import { NextRequest, NextResponse } from "next/server";
import { analyzeUrl } from "@/lib/urlClassifier";
import { validateUrlForSsrf } from "@/lib/ssrfProtection";

export interface ProbeResponse {
  success: boolean;
  url: string;
  platform: string;
  category: string;
  isDirectMedia: boolean;
  contentType: string | null;
  contentLength: number | null;
  formattedSize: string | null;
  filename: string;
  title: string;
  thumbnailUrl: string | null;
  authorName?: string;
  isHtmlWebpage: boolean;
  supportsRanges: boolean;
  canDownloadInBrowser: boolean;
  message: string;
  messageBn: string;
  error?: string;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const targetUrl = (body.url || "").trim();

    if (!targetUrl) {
      return NextResponse.json(
        { success: false, error: "Missing 'url' parameter" },
        { status: 400 }
      );
    }

    // 1. Structural and scheme analysis
    const analysis = analyzeUrl(targetUrl);
    if (!analysis.isValid) {
      return NextResponse.json({
        success: false,
        url: targetUrl,
        platform: analysis.platform,
        category: analysis.category,
        isDirectMedia: false,
        contentType: null,
        contentLength: null,
        formattedSize: null,
        filename: analysis.suggestedFilename,
        title: analysis.suggestedTitle,
        thumbnailUrl: null,
        isHtmlWebpage: false,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message: analysis.limitationReason || "Invalid URL",
        messageBn: analysis.guidanceTextBn,
        error: analysis.limitationReason,
      });
    }

    // 2. SSRF security check
    const ssrfCheck = validateUrlForSsrf(targetUrl);
    if (!ssrfCheck.isSafe) {
      return NextResponse.json({
        success: false,
        url: targetUrl,
        platform: analysis.platform,
        category: "invalid_scheme",
        isDirectMedia: false,
        contentType: null,
        contentLength: null,
        formattedSize: null,
        filename: "blocked",
        title: "Security Violation",
        thumbnailUrl: null,
        isHtmlWebpage: false,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message: `Security Warning: ${ssrfCheck.reason}`,
        messageBn: `নিরাপত্তা সতর্কতা: ${ssrfCheck.reason}`,
        error: ssrfCheck.reason,
      });
    }

    // 3. YouTube handling via official oEmbed API
    if (analysis.platform === "youtube") {
      let title = analysis.suggestedTitle;
      let authorName = "YouTube Creator";
      let thumbnailUrl = null;

      try {
        const oEmbedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(
          targetUrl
        )}&format=json`;
        const oembedRes = await fetch(oEmbedUrl, {
          headers: { "User-Agent": "VideoSaver/1.0" },
          signal: AbortSignal.timeout(4000),
        });

        if (oembedRes.ok) {
          const data = await oembedRes.json();
          title = data.title || title;
          authorName = data.author_name || authorName;
          thumbnailUrl = data.thumbnail_url || null;
        }
      } catch {
        // Fallback silently if YouTube oEmbed has transient network issue
      }

      return NextResponse.json({
        success: true,
        url: targetUrl,
        platform: "youtube",
        category: "social_media",
        isDirectMedia: false,
        contentType: "text/html",
        contentLength: null,
        formattedSize: null,
        filename: analysis.suggestedFilename,
        title,
        thumbnailUrl,
        authorName,
        isHtmlWebpage: true,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message:
          "YouTube video detected. Browser web apps cannot extract encrypted/DRM media streams without official YouTube partner authorization. You can watch the original video directly.",
        messageBn:
          "ইউটিউব ভিডিও শনাক্ত হয়েছে। ব্রাউজার থেকে সরাসরি এটি ডাউনলোড করা সম্ভব নয়। আপনি 'Open Original Video' চেপে আসল ভিডিওটি দেখতে পারেন।",
      });
    }

    // 4. Facebook handling
    if (analysis.platform === "facebook") {
      return NextResponse.json({
        success: true,
        url: targetUrl,
        platform: "facebook",
        category: "social_media",
        isDirectMedia: false,
        contentType: "text/html",
        contentLength: null,
        formattedSize: null,
        filename: analysis.suggestedFilename,
        title: analysis.suggestedTitle,
        thumbnailUrl: null,
        isHtmlWebpage: true,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message:
          "Facebook post URL detected. This URL delivers an interactive HTML page with user login/session verification, not a direct MP4 file.",
        messageBn:
          "ফেসবুক পোস্ট পাওয়া গেছে। এটি একটি ইন্টারেক্টিভ ওয়েবপেজ, কোনো সরাসরি MP4 ফাইল নয়। দেখার জন্য 'Open Original Video' চাপুন।",
      });
    }

    // 5. Pinterest handling
    if (analysis.platform === "pinterest") {
      return NextResponse.json({
        success: true,
        url: targetUrl,
        platform: "pinterest",
        category: "social_media",
        isDirectMedia: false,
        contentType: "text/html",
        contentLength: null,
        formattedSize: null,
        filename: analysis.suggestedFilename,
        title: analysis.suggestedTitle,
        thumbnailUrl: null,
        isHtmlWebpage: true,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message:
          "Pinterest pin URL detected. This is a Pinterest gallery page. To download directly, supply the direct media asset URL (e.g. ending in .mp4).",
        messageBn:
          "পিন্টারেস্ট পিন শনাক্ত হয়েছে। এটি একটি গ্যালারি ওয়েবপেজ। সরাসরি ডাউনলোড করতে মিডিয়ার আসল MP4 লিংক প্রবেশ করান।",
      });
    }

    // 6. Direct media or general URL inspection via HEAD or Range GET
    let contentType: string | null = null;
    let contentLength: number | null = null;
    let supportsRanges = false;
    let finalUrl = targetUrl;
    let serverFilename: string | null = null;

    try {
      // First try a HEAD request
      let probeRes = await fetch(targetUrl, {
        method: "HEAD",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 VideoSaver/1.0",
          Accept: "*/*",
        },
        redirect: "follow",
        signal: AbortSignal.timeout(6000),
      });

      // If HEAD is not supported (405 or 403), try a minimal Range GET (0-1 byte)
      if (probeRes.status === 405 || probeRes.status === 403 || probeRes.status === 501) {
        probeRes = await fetch(targetUrl, {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 VideoSaver/1.0",
            Range: "bytes=0-1",
          },
          redirect: "follow",
          signal: AbortSignal.timeout(6000),
        });
      }

      finalUrl = probeRes.url || targetUrl;
      contentType = probeRes.headers.get("content-type");
      const cl = probeRes.headers.get("content-length");
      const cr = probeRes.headers.get("content-range");
      const cd = probeRes.headers.get("content-disposition");
      const ar = probeRes.headers.get("accept-ranges");

      if (cl) {
        const parsedCl = parseInt(cl, 10);
        if (!isNaN(parsedCl)) contentLength = parsedCl;
      } else if (cr) {
        // e.g. bytes 0-1/15728640
        const totalMatch = cr.match(/\/(\d+)$/);
        if (totalMatch) {
          const total = parseInt(totalMatch[1], 10);
          if (!isNaN(total)) contentLength = total;
        }
      }

      if (ar && ar.toLowerCase() === "bytes") {
        supportsRanges = true;
      }

      // Check content-disposition for suggested filename
      if (cd && cd.includes("filename=")) {
        const match = cd.match(/filename=["']?([^"';]+)["']?/);
        if (match && match[1]) {
          serverFilename = match[1].trim();
        }
      }
    } catch (fetchErr) {
      const errMsg = fetchErr instanceof Error ? fetchErr.message : "Network error";
      return NextResponse.json({
        success: false,
        url: targetUrl,
        platform: analysis.platform,
        category: analysis.category,
        isDirectMedia: analysis.isDirectMediaCandidate,
        contentType: null,
        contentLength: null,
        formattedSize: null,
        filename: analysis.suggestedFilename,
        title: analysis.suggestedTitle,
        thumbnailUrl: null,
        isHtmlWebpage: false,
        supportsRanges: false,
        canDownloadInBrowser: false,
        message: `Network probe failed: Unable to connect to server (${errMsg}). The server may be unreachable, offline, or blocking probe requests.`,
        messageBn: `নেটওয়ার্ক সংযোগ ত্রুটি: সার্ভারের সাথে সংযোগ করা যায়নি (${errMsg})।`,
        error: errMsg,
      });
    }

    // Check if response is video
    const cleanContentType = (contentType || "").toLowerCase();
    const isVideoMime =
      cleanContentType.includes("video/") ||
      cleanContentType.includes("application/octet-stream") ||
      cleanContentType.includes("application/x-mpegurl") ||
      cleanContentType.includes("application/vnd.apple.mpegurl");

    const isHtml = cleanContentType.includes("text/html");

    const chosenFilename = serverFilename || analysis.suggestedFilename;

    if (isHtml) {
      return NextResponse.json({
        success: true,
        url: finalUrl,
        platform: analysis.platform,
        category: "general_webpage",
        isDirectMedia: false,
        contentType: cleanContentType,
        contentLength,
        formattedSize: contentLength ? formatBytes(contentLength) : null,
        filename: chosenFilename,
        title: analysis.suggestedTitle,
        thumbnailUrl: null,
        isHtmlWebpage: true,
        supportsRanges,
        canDownloadInBrowser: false,
        message:
          "This URL returned an HTML webpage, not a direct video stream. A direct media URL (.mp4, .webm) is required for downloading.",
        messageBn:
          "এই লিংকটি একটি সাধারণ এইচটিএমএল ওয়েবপেজ প্রদান করেছে, কোনো ভিডিও ফাইল নয়। ডাউনলোডের জন্য আসল মিডিয়া ফাইলের লিংক দিন।",
      });
    }

    const canDownloadInBrowser = isVideoMime || analysis.isDirectMediaCandidate;

    return NextResponse.json({
      success: true,
      url: finalUrl,
      platform: "direct",
      category: "direct_media",
      isDirectMedia: true,
      contentType: cleanContentType || "video/mp4",
      contentLength,
      formattedSize: contentLength ? formatBytes(contentLength) : "Unknown size",
      filename: chosenFilename,
      title: analysis.suggestedTitle,
      thumbnailUrl: null,
      isHtmlWebpage: false,
      supportsRanges,
      canDownloadInBrowser,
      message: canDownloadInBrowser
        ? "Valid direct media stream confirmed! You can proceed to download this file."
        : "Server responded, but media type is not a recognized video stream.",
      messageBn: canDownloadInBrowser
        ? "সঠিক ডিরেক্ট ভিডিও ফাইল নিশ্চিত করা হয়েছে! আপনি এটি ডাউনলোড করতে পারেন।"
        : "সার্ভার সাড়া দিয়েছে, তবে এটি স্বীকৃত ভিডিও স্ট্রিম নয়।",
    });
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : "Internal probe error";
    return NextResponse.json(
      { success: false, error: errorMsg },
      { status: 500 }
    );
  }
}
