export type PlatformType = "youtube" | "facebook" | "pinterest" | "direct" | "unknown";
export type UrlCategory = "direct_media" | "social_media" | "invalid_scheme" | "invalid_format" | "general_webpage";

export interface ParsedUrlAnalysis {
  isValid: boolean;
  rawUrl: string;
  normalizedUrl: string;
  scheme: string;
  hostname: string;
  pathname: string;
  platform: PlatformType;
  category: UrlCategory;
  isDirectMediaCandidate: boolean;
  mediaExtension: string | null;
  videoId?: string;
  suggestedTitle: string;
  suggestedFilename: string;
  limitationReason?: string;
  guidanceText: string;
  guidanceTextBn: string;
}

const VIDEO_EXTENSIONS = [".mp4", ".webm", ".ogv", ".mov", ".m4v", ".mkv"];

export function analyzeUrl(inputUrl: string): ParsedUrlAnalysis {
  const trimmed = (inputUrl || "").trim();

  if (!trimmed) {
    return {
      isValid: false,
      rawUrl: trimmed,
      normalizedUrl: "",
      scheme: "",
      hostname: "",
      pathname: "",
      platform: "unknown",
      category: "invalid_format",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Empty URL",
      suggestedFilename: "video.mp4",
      limitationReason: "Please enter a valid web URL starting with https:// or http://",
      guidanceText: "URL cannot be empty.",
      guidanceTextBn: "দয়া করে https:// অথবা http:// দিয়ে শুরু হওয়া একটি সঠিক লিংক দিন।",
    };
  }

  // Scheme pre-check
  const schemeMatch = trimmed.match(/^([a-zA-Z0-9+.-]+):/);
  const scheme = schemeMatch ? schemeMatch[1].toLowerCase() : "";

  const UNSAFE_SCHEMES = ["javascript", "data", "file", "vbscript", "about", "chrome", "blob"];
  if (UNSAFE_SCHEMES.includes(scheme)) {
    return {
      isValid: false,
      rawUrl: trimmed,
      normalizedUrl: trimmed,
      scheme,
      hostname: "",
      pathname: "",
      platform: "unknown",
      category: "invalid_scheme",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Unsafe URL Scheme",
      suggestedFilename: "rejected.txt",
      limitationReason: `Unsafe scheme '${scheme}:' is blocked for browser security. Only 'http://' and 'https://' are permitted.`,
      guidanceText: `Security rejection: '${scheme}:' protocols are not allowed to protect your Android device from cross-site scripting or local file leaks.`,
      guidanceTextBn: `নিরাপত্তার স্বার্থে '${scheme}:' স্কিম বাতিল করা হয়েছে। ব্রাউজার নিরাপত্তার জন্য কেবল http:// এবং https:// লিংক গ্রহণযোগ্য।`,
    };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return {
      isValid: false,
      rawUrl: trimmed,
      normalizedUrl: trimmed,
      scheme,
      hostname: "",
      pathname: "",
      platform: "unknown",
      category: "invalid_format",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Invalid URL Format",
      suggestedFilename: "video.mp4",
      limitationReason: "Malformed URL syntax. Make sure it includes http:// or https:// and a valid domain name.",
      guidanceText: "Could not parse URL format. Please check the spelling and try again.",
      guidanceTextBn: "লিংকের গঠন সঠিক নয়। নিশ্চিত করুন লিংকটি http:// বা https:// সহ সঠিক ডোমেন সম্বলিত।",
    };
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return {
      isValid: false,
      rawUrl: trimmed,
      normalizedUrl: parsed.href,
      scheme: parsed.protocol.replace(":", ""),
      hostname: parsed.hostname,
      pathname: parsed.pathname,
      platform: "unknown",
      category: "invalid_scheme",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Unsupported Protocol",
      suggestedFilename: "video.mp4",
      limitationReason: `Protocol '${parsed.protocol}' is not supported. Use http:// or https://.`,
      guidanceText: "Only standard web protocols (HTTP and HTTPS) are supported.",
      guidanceTextBn: "কেবল স্ট্যান্ডার্ড HTTP এবং HTTPS প্রোটোকল সমর্থিত।",
    };
  }

  const hostname = parsed.hostname.toLowerCase();
  const pathname = parsed.pathname;
  const searchParams = parsed.searchParams;

  // Check if pathname has a direct video extension
  let mediaExt: string | null = null;
  const lowerPath = pathname.toLowerCase();
  for (const ext of VIDEO_EXTENSIONS) {
    if (lowerPath.endsWith(ext) || lowerPath.includes(`${ext}/`)) {
      mediaExt = ext;
      break;
    }
  }

  // Generate a clean filename from pathname
  const pathSegments = pathname.split("/").filter(Boolean);
  const lastSegment = pathSegments.length > 0 ? pathSegments[pathSegments.length - 1] : "";
  let baseFilename = lastSegment ? decodeURIComponent(lastSegment) : "video";
  // remove existing video extension from baseFilename if needed
  for (const ext of VIDEO_EXTENSIONS) {
    if (baseFilename.toLowerCase().endsWith(ext)) {
      baseFilename = baseFilename.slice(0, -ext.length);
      break;
    }
  }
  // sanitize filename
  baseFilename = baseFilename.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40) || "video";
  const defaultExt = mediaExt || ".mp4";
  const suggestedFilename = `${baseFilename}${defaultExt}`;

  // 1. YouTube Detection
  if (
    hostname === "youtube.com" ||
    hostname === "www.youtube.com" ||
    hostname === "m.youtube.com" ||
    hostname === "youtu.be" ||
    hostname === "music.youtube.com"
  ) {
    let videoId: string | undefined;
    if (hostname === "youtu.be") {
      videoId = pathname.replace("/", "").split(/[?#]/)[0];
    } else if (pathname.startsWith("/watch")) {
      videoId = searchParams.get("v") || undefined;
    } else if (pathname.startsWith("/shorts/")) {
      videoId = pathname.replace("/shorts/", "").split(/[/?#]/)[0];
    } else if (pathname.startsWith("/embed/")) {
      videoId = pathname.replace("/embed/", "").split(/[/?#]/)[0];
    }

    return {
      isValid: true,
      rawUrl: trimmed,
      normalizedUrl: parsed.href,
      scheme: parsed.protocol.replace(":", ""),
      hostname,
      pathname,
      platform: "youtube",
      category: "social_media",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      videoId,
      suggestedTitle: videoId ? `YouTube Video (${videoId})` : "YouTube Link",
      suggestedFilename: `youtube_${videoId || "clip"}.mp4`,
      limitationReason:
        "YouTube video streams are protected by YouTube Terms of Service and dynamic DRM/cipher signatures. Client web browsers cannot extract raw MP4 files without official partner API authorization.",
      guidanceText:
        "Official behavior: You can open the original YouTube video directly or view its verified metadata (title, author, thumbnail) via the official YouTube oEmbed API.",
      guidanceTextBn:
        "ইউটিউব ভিডিও স্ট্রিম কপিরাইট ও DRM দ্বারা সুরক্ষিত। ওয়েব ব্রাউজারের ভেতর থেকে কোনো অননুমোদিত স্ক্র্যাপিং করা নিয়মবহির্ভূত। আপনি অফিসিয়াল লিংকের মাধ্যমে সরাসরি মূল ভিডিও দেখতে পারেন বা প্রিভিউ দেখতে পারেন।",
    };
  }

  // 2. Facebook Detection
  if (
    hostname === "facebook.com" ||
    hostname === "www.facebook.com" ||
    hostname === "m.facebook.com" ||
    hostname === "web.facebook.com" ||
    hostname === "fb.watch" ||
    hostname.endsWith(".facebook.com")
  ) {
    return {
      isValid: true,
      rawUrl: trimmed,
      normalizedUrl: parsed.href,
      scheme: parsed.protocol.replace(":", ""),
      hostname,
      pathname,
      platform: "facebook",
      category: "social_media",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Facebook Post / Video",
      suggestedFilename: "facebook_video.mp4",
      limitationReason:
        "Facebook social post URLs point to interactive HTML web pages with session cookies, login walls, and authenticated feeds. They are not direct MP4 file URLs.",
      guidanceText:
        "Facebook does not provide a public unauthenticated direct MP4 download API for arbitrary posts. Use 'Open Original Video' to view the content on Facebook.",
      guidanceTextBn:
        "ফেসবুক পোস্ট লিংক সরাসরি কোনো MP4 ভিডিও ফাইল নয়, এটি একটি ফেসবুক ওয়েবপেজ। প্রাইভেসি ও লগইন সুরক্ষার কারণে ব্রাউজার থেকে সরাসরি এটি ডাউনলোড করা সম্ভব নয়। মূল ভিডিওটি দেখতে 'Open Original Video' চাপুন।",
    };
  }

  // 3. Pinterest Detection
  if (
    hostname === "pinterest.com" ||
    hostname === "www.pinterest.com" ||
    hostname === "pin.it" ||
    hostname.endsWith(".pinterest.com")
  ) {
    return {
      isValid: true,
      rawUrl: trimmed,
      normalizedUrl: parsed.href,
      scheme: parsed.protocol.replace(":", ""),
      hostname,
      pathname,
      platform: "pinterest",
      category: "social_media",
      isDirectMediaCandidate: false,
      mediaExtension: null,
      suggestedTitle: "Pinterest Pin",
      suggestedFilename: "pinterest_pin.mp4",
      limitationReason:
        "Pinterest pins are web gallery containers that may contain images, stories, or dynamic HTML players. An authorized API or direct media CDN URL is required for file saving.",
      guidanceText:
        "Social media webpage detected. If you have the direct media link (e.g. from v.pinimg.com/*.mp4), you can paste it directly to download.",
      guidanceTextBn:
        "পিন্টারেস্ট পিন একটি ওয়েবপেজ। এটি থেকে সরাসরি ভিডিও সেভ করতে পিন্টারেস্টের আসল ডিরেক্ট মিডিয়া ফাইল লিংক (যেমন v.pinimg.com/*.mp4) প্রয়োজন।",
    };
  }

  // 4. Direct Media Candidate
  if (mediaExt) {
    return {
      isValid: true,
      rawUrl: trimmed,
      normalizedUrl: parsed.href,
      scheme: parsed.protocol.replace(":", ""),
      hostname,
      pathname,
      platform: "direct",
      category: "direct_media",
      isDirectMediaCandidate: true,
      mediaExtension: mediaExt,
      suggestedTitle: `${baseFilename}${mediaExt}`,
      suggestedFilename,
      guidanceText:
        "Direct media file detected! Click 'Validate Link' to inspect file headers and size, then click 'Download Video' to download.",
      guidanceTextBn:
        "ডিরেক্ট মিডিয়া ফাইল পাওয়া গেছে! ফাইলের সাইজ ও হেডার যাচাই করতে 'Validate Link' চাপুন, এরপর 'Download Video' চেপে নামিয়ে নিন।",
    };
  }

  // 5. Other general webpage / potential CDN link without extension
  return {
    isValid: true,
    rawUrl: trimmed,
    normalizedUrl: parsed.href,
    scheme: parsed.protocol.replace(":", ""),
    hostname,
    pathname,
    platform: "unknown",
    category: "general_webpage",
    isDirectMediaCandidate: true, // might be a direct stream URL without extension
    mediaExtension: null,
    suggestedTitle: `${hostname} media`,
    suggestedFilename,
    limitationReason:
      "This URL does not have an obvious .mp4 extension. Click 'Validate Link' so our probe can inspect the server's Content-Type header to see if it is a genuine video stream.",
    guidanceText:
      "URL parsed. Use 'Validate Link' to check if the server serves a real video MIME type (video/mp4, video/webm).",
    guidanceTextBn:
      "লিংকটি বিশ্লেষণ করা হয়েছে। সার্ভারের Content-Type পরীক্ষা করতে 'Validate Link' চাপুন।",
  };
}
