import net from "net";

export interface SsrfCheckResult {
  isSafe: boolean;
  reason?: string;
}

/**
 * Checks whether an IPv4 address string is private, loopback, link-local, or reserved.
 */
function isPrivateOrReservedIPv4(ip: string): boolean {
  const parts = ip.split(".").map((n) => parseInt(n, 10));
  if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) {
    return true; // invalid format considered unsafe
  }

  const [a, b] = parts;

  // 0.0.0.0/8 - Broadcast / This host
  if (a === 0) return true;

  // 127.0.0.0/8 - Loopback
  if (a === 127) return true;

  // 10.0.0.0/8 - Private Class A
  if (a === 10) return true;

  // 172.16.0.0/12 - Private Class B (172.16.0.0 - 172.31.255.255)
  if (a === 172 && b >= 16 && b <= 31) return true;

  // 192.168.0.0/16 - Private Class C
  if (a === 192 && b === 168) return true;

  // 169.254.0.0/16 - Link-Local (Cloud metadata e.g. AWS/GCP 169.254.169.254)
  if (a === 169 && b === 254) return true;

  // 100.64.0.0/10 - Shared address space (Carrier-grade NAT)
  if (a === 100 && b >= 64 && b <= 127) return true;

  // 198.18.0.0/15 - Benchmarking
  if (a === 198 && (b === 18 || b === 19)) return true;

  // 224.0.0.0/4 - Multicast & 240.0.0.0/4 - Reserved
  if (a >= 224) return true;

  return false;
}

/**
 * Validates a target URL against SSRF threats.
 */
export function validateUrlForSsrf(inputUrl: string): SsrfCheckResult {
  let parsed: URL;
  try {
    parsed = new URL(inputUrl);
  } catch {
    return { isSafe: false, reason: "Malformed URL syntax" };
  }

  // Only permit HTTP and HTTPS
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return {
      isSafe: false,
      reason: `Blocked scheme '${parsed.protocol}'. Only http: and https: protocols are permitted.`,
    };
  }

  // Disallow user credentials in URL (e.g., http://user:pass@host)
  if (parsed.username || parsed.password) {
    return { isSafe: false, reason: "Embedded username or password credentials in URL are prohibited." };
  }

  const hostname = parsed.hostname.toLowerCase();

  // Strip brackets from IPv6 hostnames like [::1]
  const cleanHost = hostname.replace(/^\[|\]$/g, "");

  // Check known dangerous hostnames
  const dangerousHostnames = [
    "localhost",
    "loopback",
    "0.0.0.0",
    "127.0.0.1",
    "::1",
    "metadata.google.internal",
    "instance-data",
  ];
  if (dangerousHostnames.includes(cleanHost)) {
    return { isSafe: false, reason: `Direct access to '${cleanHost}' is forbidden (SSRF protection).` };
  }

  // Disallow internal / mDNS / local domain suffixes
  const blockedSuffixes = [".local", ".localhost", ".internal", ".lan", ".corp", ".home", ".arpa", ".test"];
  for (const suffix of blockedSuffixes) {
    if (cleanHost.endsWith(suffix)) {
      return { isSafe: false, reason: `Access to internal domain '${cleanHost}' is forbidden.` };
    }
  }

  // Check if hostname is an IP address
  const ipType = net.isIP(cleanHost);
  if (ipType === 4) {
    if (isPrivateOrReservedIPv4(cleanHost)) {
      return {
        isSafe: false,
        reason: `Target IP address ${cleanHost} belongs to a private, loopback, or cloud-metadata range. Access blocked.`,
      };
    }
  } else if (ipType === 6) {
    // IPv6 checks
    const lowerIpv6 = cleanHost.toLowerCase();
    if (
      lowerIpv6 === "::1" ||
      lowerIpv6 === "::" ||
      lowerIpv6.startsWith("fe80:") || // link-local
      lowerIpv6.startsWith("fc00:") || // unique local
      lowerIpv6.startsWith("fd00:") // unique local
    ) {
      return {
        isSafe: false,
        reason: `Target IPv6 address ${cleanHost} belongs to a loopback, link-local, or private range. Access blocked.`,
      };
    }
  }

  // Check port if specified: block internal sensitive ports
  if (parsed.port) {
    const port = parseInt(parsed.port, 10);
    const blockedPorts = [22, 25, 53, 110, 143, 445, 5432, 3306, 6379, 27017, 9200, 2375, 2376];
    if (blockedPorts.includes(port)) {
      return { isSafe: false, reason: `Port ${port} is reserved for internal infrastructure services.` };
    }
  }

  return { isSafe: true };
}
